﻿namespace Student_Registration
{
    partial class StudentInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentInformation));
            maskedTextBox_contact = new MaskedTextBox();
            txtEmail = new TextBox();
            txtMiddleName = new TextBox();
            txtLastName = new TextBox();
            txtFirstName = new TextBox();
            txtPassword = new TextBox();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            back = new PictureBox();
            label9 = new Label();
            txtbx_totalRecievePoints = new TextBox();
            ((System.ComponentModel.ISupportInitialize)back).BeginInit();
            SuspendLayout();
            // 
            // maskedTextBox_contact
            // 
            maskedTextBox_contact.BackColor = Color.LightGray;
            maskedTextBox_contact.BorderStyle = BorderStyle.None;
            maskedTextBox_contact.CutCopyMaskFormat = MaskFormat.IncludePrompt;
            maskedTextBox_contact.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            maskedTextBox_contact.ForeColor = Color.DarkGray;
            maskedTextBox_contact.Location = new Point(202, 268);
            maskedTextBox_contact.Margin = new Padding(3, 2, 3, 2);
            maskedTextBox_contact.Mask = "(+63) 000-000-0000";
            maskedTextBox_contact.Name = "maskedTextBox_contact";
            maskedTextBox_contact.ReadOnly = true;
            maskedTextBox_contact.Size = new Size(299, 24);
            maskedTextBox_contact.TabIndex = 177;
            maskedTextBox_contact.TextAlign = HorizontalAlignment.Center;
            maskedTextBox_contact.MaskInputRejected += maskedTextBox_contact_MaskInputRejected;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.LightGray;
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.Location = new Point(202, 318);
            txtEmail.Margin = new Padding(3, 2, 3, 2);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "example@domain.com";
            txtEmail.ReadOnly = true;
            txtEmail.Size = new Size(299, 30);
            txtEmail.TabIndex = 169;
            txtEmail.TextAlign = HorizontalAlignment.Center;
            // 
            // txtMiddleName
            // 
            txtMiddleName.BackColor = Color.LightGray;
            txtMiddleName.BorderStyle = BorderStyle.None;
            txtMiddleName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtMiddleName.Location = new Point(202, 174);
            txtMiddleName.Margin = new Padding(3, 2, 3, 2);
            txtMiddleName.Multiline = true;
            txtMiddleName.Name = "txtMiddleName";
            txtMiddleName.PlaceholderText = "Gonzales";
            txtMiddleName.ReadOnly = true;
            txtMiddleName.Size = new Size(299, 30);
            txtMiddleName.TabIndex = 169;
            txtMiddleName.TextAlign = HorizontalAlignment.Center;
            // 
            // txtLastName
            // 
            txtLastName.BackColor = Color.LightGray;
            txtLastName.BorderStyle = BorderStyle.None;
            txtLastName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.Location = new Point(202, 219);
            txtLastName.Margin = new Padding(3, 2, 3, 2);
            txtLastName.Multiline = true;
            txtLastName.Name = "txtLastName";
            txtLastName.PlaceholderText = "Dela Cruz";
            txtLastName.ReadOnly = true;
            txtLastName.Size = new Size(299, 30);
            txtLastName.TabIndex = 169;
            txtLastName.TextAlign = HorizontalAlignment.Center;
            // 
            // txtFirstName
            // 
            txtFirstName.BackColor = Color.LightGray;
            txtFirstName.BorderStyle = BorderStyle.None;
            txtFirstName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.Location = new Point(202, 125);
            txtFirstName.Margin = new Padding(3, 2, 3, 2);
            txtFirstName.Multiline = true;
            txtFirstName.Name = "txtFirstName";
            txtFirstName.PlaceholderText = "Juan ";
            txtFirstName.ReadOnly = true;
            txtFirstName.Size = new Size(299, 30);
            txtFirstName.TabIndex = 169;
            txtFirstName.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.LightGray;
            txtPassword.BorderStyle = BorderStyle.None;
            txtPassword.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(202, 364);
            txtPassword.Margin = new Padding(3, 2, 3, 2);
            txtPassword.Multiline = true;
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "Student Password";
            txtPassword.ReadOnly = true;
            txtPassword.Size = new Size(299, 30);
            txtPassword.TabIndex = 175;
            txtPassword.TextAlign = HorizontalAlignment.Center;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.TextChanged += txtPassword_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI Semibold", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Maroon;
            label2.Location = new Point(226, 70);
            label2.Name = "label2";
            label2.Size = new Size(214, 40);
            label2.TabIndex = 179;
            label2.Tag = "50,50";
            label2.Text = "INFORMATION";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI Semibold", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(92, 70);
            label1.Name = "label1";
            label1.Size = new Size(143, 40);
            label1.TabIndex = 178;
            label1.Tag = "50,50";
            label1.Text = "STUDENT";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(46, 134);
            label3.Name = "label3";
            label3.Size = new Size(96, 20);
            label3.TabIndex = 181;
            label3.Text = "First Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(46, 222);
            label4.Name = "label4";
            label4.Size = new Size(95, 20);
            label4.TabIndex = 181;
            label4.Text = "Last Name";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(46, 177);
            label5.Name = "label5";
            label5.Size = new Size(112, 20);
            label5.TabIndex = 182;
            label5.Text = "Middle Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(46, 318);
            label6.Name = "label6";
            label6.Size = new Size(124, 20);
            label6.TabIndex = 183;
            label6.Text = "Email Address";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.White;
            label7.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(46, 271);
            label7.Name = "label7";
            label7.Size = new Size(139, 20);
            label7.TabIndex = 184;
            label7.Text = "Contact Number";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.White;
            label8.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(46, 367);
            label8.Name = "label8";
            label8.Size = new Size(86, 20);
            label8.TabIndex = 185;
            label8.Text = "Password";
            // 
            // back
            // 
            back.BackColor = Color.Transparent;
            back.Image = (Image)resources.GetObject("back.Image");
            back.Location = new Point(515, 31);
            back.Name = "back";
            back.Size = new Size(21, 18);
            back.SizeMode = PictureBoxSizeMode.StretchImage;
            back.TabIndex = 187;
            back.TabStop = false;
            back.Click += back_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.White;
            label9.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(46, 413);
            label9.Name = "label9";
            label9.Size = new Size(128, 20);
            label9.TabIndex = 189;
            label9.Text = "Receive Points";
            label9.Click += label9_Click;
            // 
            // txtbx_totalRecievePoints
            // 
            txtbx_totalRecievePoints.BackColor = Color.LightGray;
            txtbx_totalRecievePoints.BorderStyle = BorderStyle.None;
            txtbx_totalRecievePoints.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtbx_totalRecievePoints.Location = new Point(202, 410);
            txtbx_totalRecievePoints.Margin = new Padding(3, 2, 3, 2);
            txtbx_totalRecievePoints.Multiline = true;
            txtbx_totalRecievePoints.Name = "txtbx_totalRecievePoints";
            txtbx_totalRecievePoints.PlaceholderText = "Total Recieve Points";
            txtbx_totalRecievePoints.ReadOnly = true;
            txtbx_totalRecievePoints.Size = new Size(299, 30);
            txtbx_totalRecievePoints.TabIndex = 188;
            txtbx_totalRecievePoints.TextAlign = HorizontalAlignment.Center;
            txtbx_totalRecievePoints.UseSystemPasswordChar = true;
            // 
            // StudentInformation
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(548, 503);
            ControlBox = false;
            Controls.Add(label9);
            Controls.Add(txtbx_totalRecievePoints);
            Controls.Add(back);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(maskedTextBox_contact);
            Controls.Add(txtFirstName);
            Controls.Add(txtEmail);
            Controls.Add(txtPassword);
            Controls.Add(txtLastName);
            Controls.Add(txtMiddleName);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "StudentInformation";
            Text = "StudentInformation";
            Load += StudentInformation_Load;
            ((System.ComponentModel.ISupportInitialize)back).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private MaskedTextBox maskedTextBox_contact;
        private TextBox txtEmail;
        private TextBox txtMiddleName;
        private TextBox txtLastName;
        private TextBox txtFirstName;
        private TextBox txtPassword;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private PictureBox back;
        private Label label9;
        private TextBox txtbx_totalRecievePoints;
    }
}