﻿using MySql.Data.MySqlClient;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Student_Registration
{
    public partial class Register : Form
    {
        error_handling ER = new error_handling();

        //for raduis button
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
           int nLeftRect, // x-coordinate of upper-left corner
           int nTopRect, // y-coordinate of upper-left corner
           int nRightRect, // x-coordinate of lower-right corner
           int nBottomRect, // y-coordinate of lower-right corner
           int nWidthEllipse, // height of ellipse
           int nHeightEllipse // width of ellipse
        );

        // Define class-level fields
        public int prof_ID;
        public string password;
        public string sub_code;
        public int ID;
        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";

        // Parameterless constructor
        public Register()
        {
            InitializeComponent();

            //for raduis button
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            btn_uploadPhoto.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_uploadPhoto.Width, btn_uploadPhoto.Height, 5, 5));
            txtFirstName.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtFirstName.Width, txtFirstName.Height, 5, 5));
            txtLastName.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtLastName.Width, txtLastName.Height, 5, 5));
            txt_classPass.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txt_classPass.Width, txt_classPass.Height, 5, 5));
            cbCourse.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, cbCourse.Width, cbCourse.Height, 5, 5));
            cbSection.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, cbSection.Width, cbSection.Height, 5, 5));
            btn_ClassRegister.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_ClassRegister.Width, btn_ClassRegister.Height, 5, 5));
        }

        // Parameterized constructor that chains to the parameterless constructor
        public Register(string classPassword, string sCode, int profId) : this()
        {
            this.password = classPassword;
            this.sub_code = sCode;
            this.prof_ID = profId;
            txtFirstName.Text = SignIn.f_name;
            txtLastName.Text = SignIn.l_name;
            classPassword = txt_classPass.Text;
            this.sub_code = sub_code;
            this.prof_ID = prof_ID;
            cbCourse.Items.Add("BSIT");
            cbCourse.Items.Add("BSHM");
            cbCourse.Items.Add("BSCPE");

            cbSection.Items.Add("1-1");
            cbSection.Items.Add("1-2");
            cbSection.Items.Add("2-1");
            cbSection.Items.Add("2-2");

            cbCourse.SelectedIndex = 0;
            cbSection.SelectedIndex = 0;

            lbl_CodeSub.Text = $"{sub_code}";
            txt_classPass.ReadOnly = true;
            txt_classPass.Text = password;
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void btn_ClassRegister_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_ClassRegister_Click_1(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            pic_uploadPhoto.Image.Save(ms, pic_uploadPhoto.Image.RawFormat);
            byte[] imageBytes = ms.ToArray();
            if (ER.notNull(txtFirstName.Text) && ER.notNull(txtLastName.Text))
            {
                if (ER.namesChecker(txtFirstName.Text) && ER.namesChecker(txtLastName.Text))
                {
                    using (MySqlConnection con = new MySqlConnection(constring))
                    {
                        con.Open();

                        // Check if the student is already enrolled in the subject
                        string checkQuery = "SELECT COUNT(*) FROM lifepoints_tb WHERE std_ID = @std_ID AND subj_code = @subj_code";
                        MySqlCommand checkCmd = new MySqlCommand(checkQuery, con);
                        checkCmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);
                        checkCmd.Parameters.AddWithValue("@subj_code", sub_code);

                        int enrollmentCount = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (enrollmentCount > 0)
                        {
                            MessageBox.Show("Already enrolled in this subject.", "Enrollment Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            // Insert into register_proxy table
                            string insertQuery = "INSERT INTO register_proxy (prof_id, std_fname, std_lname, class_pass, course, section, std_ID, std_picture) " +
                                                 "VALUES (@prof_id, @std_fname, @std_lname, @class_pass, @course, @section, @studentID, @picture)";

                            MySqlCommand insertCmd = new MySqlCommand(insertQuery, con);
                            insertCmd.Parameters.AddWithValue("@prof_id", prof_ID);
                            insertCmd.Parameters.AddWithValue("@std_fname", txtFirstName.Text);
                            insertCmd.Parameters.AddWithValue("@std_lname", txtLastName.Text);
                            insertCmd.Parameters.AddWithValue("@class_pass", password);
                            insertCmd.Parameters.AddWithValue("@course", cbCourse.SelectedItem.ToString());
                            insertCmd.Parameters.AddWithValue("@section", cbSection.SelectedItem.ToString());
                            insertCmd.Parameters.AddWithValue("@studentID", SignIn.student_ID);
                            insertCmd.Parameters.AddWithValue("@picture", imageBytes);
                            insertCmd.ExecuteNonQuery();

                            // Insert into registered_class table
                            string insertClassQuery = "INSERT INTO lifepoints_tb (std_ID, subj_code) VALUES (@std_ID, @s_code)";
                            MySqlCommand insertClassCmd = new MySqlCommand(insertClassQuery, con);
                            insertClassCmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);
                            insertClassCmd.Parameters.AddWithValue("@s_code", sub_code);

                            insertClassCmd.ExecuteNonQuery();

                            MessageBox.Show("Registered Successfully!", "Created by TEAM U.N.I.T.Y", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Names must not contain numeric characters", "Invalid name", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Fields should not be empty", "Empty field", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_uploadPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "Select Photo(*.jpg;*.png;*.gif) |*.jpg;*.png;*.gif";

            if (opf.ShowDialog() == DialogResult.OK)
            {
                pic_uploadPhoto.Image = Image.FromFile(opf.FileName);
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
