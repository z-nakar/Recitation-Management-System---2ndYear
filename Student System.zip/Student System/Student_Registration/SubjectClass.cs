﻿using MySql.Data.MySqlClient;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Student_Registration
{
    public partial class SubjectClass : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );

        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        string sub_code;
        int life_points;
        public static double recitation_points;
        private System.Windows.Forms.Timer timer_;

        public SubjectClass()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            btnParticipate.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btnParticipate.Width, btnParticipate.Height, 5, 5));
            pictureBox1.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, pictureBox1.Width, pictureBox4.Height, 5, 5));
            pictureBox4.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, pictureBox4.Width, pictureBox4.Height, 5, 5));

            timer_ = new System.Windows.Forms.Timer();
            timer_.Interval = 1000;
            timer_.Tick += Timer_Tick;
            timer_.Start();
        }

        public SubjectClass(string subjectCode, int lifePoints) : this()
        {
            this.sub_code = subjectCode;
            this.life_points = lifePoints;
            label_greet.Text += sub_code;
            label_life.Text = "Life: " + life_points.ToString();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(constring))
                {
                    connection.Open();
                    string selectQuery = "SELECT life_points FROM lifepoints_tb WHERE std_ID = @std_id AND subj_code = @subj_code";
                    using (MySqlCommand cmd = new MySqlCommand(selectQuery, connection))
                    {

                        cmd.Parameters.AddWithValue("@std_id", SignIn.student_ID);
                        cmd.Parameters.AddWithValue("@subj_code", sub_code);
                        object result = cmd.ExecuteScalar();
                        if (result != null && int.TryParse(result.ToString(), out int fetchedLifePoints))
                        {
                            life_points = fetchedLifePoints;

                            // Update progress bars and life points on the UI thread
                            if (this.InvokeRequired)
                            {
                                this.Invoke(new Action(UpdateProgressBarsAndLifePoints));
                            }
                            else
                            {
                                UpdateProgressBarsAndLifePoints();
                            }
                        }
                        else
                        {
                            Console.WriteLine("[Timer_Tick] Failed to fetch life_points from database.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"[Timer_Tick] An error occurred while fetching life points: {ex.Message}");
            }
        }

        private void UpdateProgressBarsAndLifePoints()
        {
            progressBar_life1.Value = life_points >= 1 ? 100 : 0;
            progressBar_life2.Value = life_points >= 2 ? 100 : 0;
            progressBar_life3.Value = life_points >= 3 ? 100 : 0;
            label_life.Text = "Life: " + life_points.ToString();
        }


        private void SubjectClass_Load(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(constring))
                {
                    connection.Open();
                    string selectQuery = "SELECT recitation_pts FROM signup_tb WHERE std_ID = @ID";
                    using (MySqlCommand cmd3 = new MySqlCommand(selectQuery, connection))
                    {
                        cmd3.Parameters.AddWithValue("@ID", SignIn.student_ID);
                        object points = cmd3.ExecuteScalar();
                        if (points != null)
                        {
                            recitation_points = Convert.ToDouble(points);
                            label_Points.Text = $"Points: {recitation_points}";
                        }
                        else
                        {
                            Console.WriteLine("No records found for the given student ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void btnParticipate_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(constring))
                {
                    conn.Open();
                    string query2 = "SELECT start_time, end_time, day_ FROM linkgenerator_proxy WHERE subj_code = @scode";
                    using (MySqlCommand cmd2 = new MySqlCommand(query2, conn))
                    {
                        cmd2.Parameters.AddWithValue("@scode", sub_code);
                        using (MySqlDataReader reader = cmd2.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string startTime = reader["start_time"].ToString();
                                string endTime = reader["end_time"].ToString();
                                string day = reader["day_"].ToString();

                                if (CheckLifeAndTime(startTime, endTime, day))
                                {
                                    reader.Close();
                                    if (life_points > 0)
                                    {
                                        Console.WriteLine($"Life points before decrement: {life_points}");
                                        life_points--;


                                        UpdateProgressBarsAndLifePoints();

                                        string updateQuery = "UPDATE lifepoints_tb SET life_points = @new_life_points WHERE std_ID = @std_id";
                                        using (MySqlCommand updateCmd = new MySqlCommand(updateQuery, conn))
                                        {
                                            updateCmd.Parameters.AddWithValue("@new_life_points", life_points);
                                            updateCmd.Parameters.AddWithValue("@std_id", SignIn.student_ID);
                                            updateCmd.ExecuteNonQuery();
                                        }

                                        UpdateRecitationPoints(conn);

                                        string updateQuery4 = "UPDATE register_proxy SET status_code = @status_code WHERE std_ID = @ID";
                                        using (MySqlCommand updateCMD3 = new MySqlCommand(updateQuery4, conn))
                                        {
                                            updateCMD3.Parameters.AddWithValue("@status_code", 1);
                                            updateCMD3.Parameters.AddWithValue("@ID", SignIn.student_ID);
                                            updateCMD3.ExecuteNonQuery();
                                        }

                                        MessageBox.Show("Participation registered successfully.");
                                    }
                                    else
                                    {
                                        MessageBox.Show("You cannot participate because your life points are already at 0.");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("The current time does not fall within the specified time range.");
                                }
                            }
                            else
                            {
                                MessageBox.Show("No data found in linkgenerator_proxy.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while registering participation: {ex.Message}");
            }
        }


        private void UpdateRecitationPoints(MySqlConnection conn)
        {
            string updateQuery2 = "SELECT recitation_pts FROM signup_tb WHERE std_ID = @ID";
            using (MySqlCommand cmd3 = new MySqlCommand(updateQuery2, conn))
            {
                cmd3.Parameters.AddWithValue("@ID", SignIn.student_ID);
                object points = cmd3.ExecuteScalar();
                if (points != null)
                {
                    recitation_points = Convert.ToDouble(points);
                }
            }

            recitation_points += 0.1;

            string updateQuery3 = "UPDATE signup_tb SET recitation_pts = @points WHERE std_ID = @ID";
            using (MySqlCommand updateCmd2 = new MySqlCommand(updateQuery3, conn))
            {
                updateCmd2.Parameters.AddWithValue("@points", recitation_points);
                updateCmd2.Parameters.AddWithValue("@ID", SignIn.student_ID);
                updateCmd2.ExecuteNonQuery();
            }

            label_Points.Text = $"Points: {Math.Round(recitation_points, 2):F2}";
        }

        private bool CheckLifeAndTime(string start_time, string end_time, string day)
        {
            bool flag = false;
            try
            {
                string dayInput = day.Trim();
                string startTimeInput = start_time.Trim();
                string endTimeInput = end_time.Trim();

                if (!Enum.TryParse(dayInput, true, out DayOfWeek inputDay))
                {
                    MessageBox.Show("Invalid day input.");
                    return false;
                }

                if (!TimeSpan.TryParse(startTimeInput, out TimeSpan startTime) ||
                    !TimeSpan.TryParse(endTimeInput, out TimeSpan endTime))
                {
                    MessageBox.Show("Invalid time input.");
                    return false;
                }

                DateTime now = DateTime.Now;
                DayOfWeek currentDay = now.DayOfWeek;
                TimeSpan currentTime = now.TimeOfDay;

                if (currentDay == inputDay && currentTime >= startTime && currentTime <= endTime)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

            return flag;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label_greet_Click(object sender, EventArgs e) { }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Indicator of how many times you can participate in this class", "Information about life", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your balanced points", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPoints_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
