﻿namespace Student_Registration
{
    partial class EnrolledSubject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EnrolledSubject));
            panel7 = new Panel();
            panel8 = new Panel();
            panel5 = new Panel();
            panel_class = new Panel();
            panel6 = new Panel();
            label1 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox7 = new PictureBox();
            panel_class.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            SuspendLayout();
            // 
            // panel7
            // 
            panel7.BackColor = Color.Black;
            panel7.Dock = DockStyle.Right;
            panel7.Location = new Point(509, 0);
            panel7.Margin = new Padding(3, 2, 3, 2);
            panel7.Name = "panel7";
            panel7.Size = new Size(1, 348);
            panel7.TabIndex = 2;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Black;
            panel8.Dock = DockStyle.Bottom;
            panel8.Location = new Point(0, 348);
            panel8.Margin = new Padding(3, 2, 3, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(510, 1);
            panel8.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(1, 0);
            panel5.Margin = new Padding(3, 2, 3, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(508, 1);
            panel5.TabIndex = 0;
            // 
            // panel_class
            // 
            panel_class.Controls.Add(panel5);
            panel_class.Controls.Add(panel6);
            panel_class.Controls.Add(panel7);
            panel_class.Controls.Add(panel8);
            panel_class.Location = new Point(18, 153);
            panel_class.Margin = new Padding(3, 2, 3, 2);
            panel_class.Name = "panel_class";
            panel_class.Size = new Size(510, 349);
            panel_class.TabIndex = 7;
            panel_class.Paint += panel_class_Paint;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Black;
            panel6.Dock = DockStyle.Left;
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(3, 2, 3, 2);
            panel6.Name = "panel6";
            panel6.Size = new Size(1, 348);
            panel6.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(105, 93);
            label1.Name = "label1";
            label1.Size = new Size(189, 45);
            label1.TabIndex = 8;
            label1.Text = "ENROLLED ";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(279, 93);
            label2.Name = "label2";
            label2.Size = new Size(147, 45);
            label2.TabIndex = 9;
            label2.Text = "SUBJECT";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(18, 75);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(97, 77);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(507, 30);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(21, 18);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 170;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // EnrolledSubject
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(547, 542);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(panel_class);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "EnrolledSubject";
            Text = "EnrolledSubject";
            Load += EnrolledSubject_Load;
            panel_class.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private PictureBox pictureBox1;
        private Panel panel3;
        private TextBox txt_Search;
        private Panel panel7;
        private Panel panel8;
        private Panel panel5;
        private Panel panel_class;
        private Panel panel6;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox7;
    }
}