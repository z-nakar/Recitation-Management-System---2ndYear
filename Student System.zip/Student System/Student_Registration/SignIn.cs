using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;

namespace Student_Registration
{
    public partial class SignIn : Form
    {
        error_handling ER = new error_handling();
        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        public static int student_ID;
        public static string f_name;
        public static string l_name;
        public static double pts;
        private Form activeForm = null;

        public SignIn()
        {
            InitializeComponent();
            panel_logoSide.Visible = true;
            this.AcceptButton = btn_LogIn;
        }

        private void SignIn_Load(object sender, EventArgs e)
        {

        }

        public void OpenChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_main.Controls.Add(childForm);
            panel_main.Tag = childForm;
            childForm.BringToFront();

            childForm.Show();
        }

        private void btnSignUp_Click_1(object sender, EventArgs e)
        {
            SignIn si = new SignIn();

            OpenChildForm(new SignUp(si));
        }


        private void btn_LogIn_Click(object sender, EventArgs e)
        {
            if (ER.notNull(txt_Password.Text) && ER.notNull(txt_UserName.Text))
            {
                using (MySqlConnection conn = new MySqlConnection(constring))
                {
                    try
                    {
                        conn.Open();
                        string query = "SELECT std_ID, first_name, last_name, recitation_pts from signup_tb WHERE email_ = @email AND password_ = @password";
                        using (MySqlCommand cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@email", txt_UserName.Text);
                            cmd.Parameters.AddWithValue("@password", txt_Password.Text);


                            using(MySqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    student_ID = reader.GetInt32("std_ID");
                                    f_name = reader.GetString("first_name");
                                    l_name = reader.GetString("last_name");
                                    pts = reader.GetDouble("recitation_pts");
                                    StudentSystem ss = new StudentSystem();
                                    ss.Show();
                                    this.Hide();
                                }
                                else
                                {
                                    MessageBox.Show("Wrong email or password", "Incorrect credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            else MessageBox.Show("Fields should not be empty", "Empty field", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void chck_ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chck_ShowPass.Checked)
            {
                txt_Password.UseSystemPasswordChar = false;
                txt_Password.PasswordChar = '\0'; // Clear any custom password character
            }
            else
            {
                txt_Password.UseSystemPasswordChar = true;
                txt_Password.PasswordChar = '*'; // Set the desired masking character, usually '*'
            }
        }

        private void btnForgetPass_Click(object sender, EventArgs e)
        {
            ForgotPassword fp = new ForgotPassword();
            fp.Show();
        }

        private void lbl_ProfApp_Click(object sender, EventArgs e)
        {

        }
    }
}