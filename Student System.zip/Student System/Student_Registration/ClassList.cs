﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Student_Registration
{
    public partial class ClassList : Form
    {
        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        private System.Windows.Forms.Timer timer;
        private HashSet<string> existingLinkLabels = new HashSet<string>();
        private StudentSystem parentForm;

        public ClassList(StudentSystem parentForm)
        {
            InitializeComponent();
            LoadInitialLinkLabels();
            InitializeTimer();
            this.parentForm = parentForm;
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoadInitialLinkLabels()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(constring))
                {
                    conn.Open();
                    string query = "SELECT subj_name, subj_code, prof_id FROM linkgenerator_proxy";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            int verticalPosition = 10;
                            while (reader.Read())
                            {
                                string subjName = reader.GetString("subj_name");
                                string subjCode = reader.GetString("subj_code");
                                int profId = reader.GetInt32("prof_id");

                                CreateDynamicLinkLabel(subjName, subjCode, profId, verticalPosition);
                                existingLinkLabels.Add(subjCode);
                                verticalPosition += 30; // Adjust as needed for spacing
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeTimer()
        {
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 3000; // Set interval to 3 seconds (3000 milliseconds)
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                conn.Open();
                string query = "SELECT subj_name, subj_code, prof_id FROM linkgenerator_proxy";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        int verticalPosition = panel_classSubject.Controls.Count > 0 ? panel_classSubject.Controls[panel_classSubject.Controls.Count - 1].Bottom + 10 : 10;
                        while (reader.Read())
                        {
                            string subjName = reader.GetString("subj_name");
                            string subjCode = reader.GetString("subj_code");
                            int profId = reader.GetInt32("prof_id");

                            if (!existingLinkLabels.Contains(subjCode))
                            {
                                CreateDynamicLinkLabel(subjName, subjCode, profId, verticalPosition);
                                existingLinkLabels.Add(subjCode);
                                verticalPosition += 20; // Adjust as needed for spacing
                            }
                        }
                    }
                }
            }
        }

        /*   void CreateDynamicLinkLabel(string n1, string n2, int profId, int verticalPosition)
           {
               LinkLabel dynamicLL = new LinkLabel();
               dynamicLL.Text = $"{n1} - {n2}";
               dynamicLL.Tag = (n2, profId); // Store subj_code and prof_id as a tuple in Tag property
               dynamicLL.AutoSize = true;
               dynamicLL.Top = verticalPosition;
               panel_classSubject.Controls.Add(dynamicLL);
               dynamicLL.LinkClicked += dynamicLL_Clicked;
           }
       */

        // naka gitna  uung  link label dito 
        void CreateDynamicLinkLabel(string n1, string n2, int profId, int verticalPosition)
        {
            LinkLabel dynamicLL = new LinkLabel();
            dynamicLL.Text = $"{n1} - {n2}";
            dynamicLL.Tag = (n2, profId); // Store subj_code and prof_id as a tuple in Tag property
            dynamicLL.AutoSize = true;
            dynamicLL.Top = verticalPosition;

            // Set the font and color of the LinkLabel
            dynamicLL.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular); // Change to desired font, size, and style
            dynamicLL.LinkColor = Color.Maroon; // Change to desired color


            // Add the LinkLabel to the Controls collection first to calculate its size
            panel_classSubject.Controls.Add(dynamicLL);

            // Center the LinkLabel horizontally within its parent container
            dynamicLL.Left = (panel_classSubject.ClientSize.Width - dynamicLL.Width) / 2;


            dynamicLL.LinkBehavior = LinkBehavior.NeverUnderline;

            // Subscribe to the LinkClicked event
            dynamicLL.LinkClicked += dynamicLL_Clicked;

        }

        private void dynamicLL_Clicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LinkLabel clickedLabel = sender as LinkLabel;
            if (clickedLabel != null)
            {
                var (subjCode, profId) = ((string, int))clickedLabel.Tag;
                Password passwordForm = new Password(subjCode, profId, parentForm);
                parentForm.OpenChildForm(passwordForm);
            }
        }

        private void undo_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel_main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_classSubject_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
