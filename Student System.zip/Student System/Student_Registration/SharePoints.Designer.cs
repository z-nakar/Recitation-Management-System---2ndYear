﻿namespace Student_Registration
{
    partial class SharePoints
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SharePoints));
            btnSharePoints = new Button();
            txtBalancePoints = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtPoints = new TextBox();
            btnCancel = new Button();
            pictureBox1 = new PictureBox();
            txtAccountID = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnSharePoints
            // 
            btnSharePoints.BackColor = Color.Maroon;
            btnSharePoints.FlatAppearance.BorderSize = 0;
            btnSharePoints.FlatStyle = FlatStyle.Flat;
            btnSharePoints.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnSharePoints.ForeColor = Color.White;
            btnSharePoints.Location = new Point(220, 377);
            btnSharePoints.Name = "btnSharePoints";
            btnSharePoints.Size = new Size(126, 31);
            btnSharePoints.TabIndex = 0;
            btnSharePoints.Text = "Confirm";
            btnSharePoints.UseVisualStyleBackColor = false;
            btnSharePoints.Click += btnSharePoints_Click;
            // 
            // txtBalancePoints
            // 
            txtBalancePoints.BackColor = SystemColors.Window;
            txtBalancePoints.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtBalancePoints.Location = new Point(220, 185);
            txtBalancePoints.Name = "txtBalancePoints";
            txtBalancePoints.PlaceholderText = "0";
            txtBalancePoints.ReadOnly = true;
            txtBalancePoints.Size = new Size(233, 26);
            txtBalancePoints.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(54, 185);
            label1.Name = "label1";
            label1.Size = new Size(129, 20);
            label1.TabIndex = 3;
            label1.Text = "Balance Points";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(54, 247);
            label2.Name = "label2";
            label2.Size = new Size(99, 20);
            label2.TabIndex = 4;
            label2.Text = "Account ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(154, 101);
            label3.Name = "label3";
            label3.Size = new Size(250, 31);
            label3.TabIndex = 5;
            label3.Text = "Share Your Points";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(54, 309);
            label4.Name = "label4";
            label4.Size = new Size(59, 20);
            label4.TabIndex = 8;
            label4.Text = "Points";
            // 
            // txtPoints
            // 
            txtPoints.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPoints.Location = new Point(220, 307);
            txtPoints.Name = "txtPoints";
            txtPoints.PlaceholderText = "0";
            txtPoints.Size = new Size(233, 26);
            txtPoints.TabIndex = 9;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.FromArgb(219, 167, 41);
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(364, 377);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(88, 31);
            btnCancel.TabIndex = 10;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Silver;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(429, 309);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 19);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // txtAccountID
            // 
            txtAccountID.BackColor = SystemColors.Window;
            txtAccountID.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtAccountID.Location = new Point(220, 248);
            txtAccountID.Name = "txtAccountID";
            txtAccountID.PlaceholderText = "x";
            txtAccountID.Size = new Size(232, 26);
            txtAccountID.TabIndex = 13;
            // 
            // SharePoints
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(546, 503);
            Controls.Add(txtAccountID);
            Controls.Add(pictureBox1);
            Controls.Add(btnCancel);
            Controls.Add(txtPoints);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtBalancePoints);
            Controls.Add(btnSharePoints);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "SharePoints";
            Text = "SharePoints";
            Load += SharePoints_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSharePoints;
        private TextBox txtBalancePoints;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtPoints;
        private Button btnCancel;
        private PictureBox pictureBox1;
        private TextBox txtAccountID;
    }
}