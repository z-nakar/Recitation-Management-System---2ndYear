﻿using Microsoft.Win32;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Registration
{
    public partial class Password : Form
    {
        error_handling ER = new error_handling();

        public string class_password;
        public string s_code;
        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        public int prof_id;
        StudentSystem parentForm;

        public Password()
        {
            InitializeComponent();
        }


        public Password(string subjCode, int profId, StudentSystem parentForm) : this()
        {
            this.s_code = subjCode;
            this.prof_id = profId;
            this.parentForm = parentForm;
            this.txtSubCode.Text = subjCode; // Set the TextBox text
            this.lblSubject_code.Text = subjCode; // Set the Label text
        }

        private void Password_Load(object sender, EventArgs e)
        {
            // Any additional initialization logic can go here
        }

        private void btnConfirmPassword_Click(object sender, EventArgs e)
        {
            if (ER.notNull(txtPassword.Text))
            {

                using (MySqlConnection conn = new MySqlConnection(constring))
                {
                    conn.Open();

                    string query = "SELECT class_pass, prof_id FROM linkgenerator_proxy WHERE class_pass = @password AND subj_code = @s_Code";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@s_Code", txtSubCode.Text);
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);

                        class_password = txtPassword.Text;



                        object result = cmd.ExecuteScalar();

                        if (result != null && result.ToString() == txtPassword.Text)
                        {
                            class_password = result.ToString();
                            Register r = new Register(class_password, s_code, prof_id);
                            parentForm.OpenChildForm(r);
                        }
                        else
                        {
                            MessageBox.Show("Wrong password", "Incorrect credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                }
            }
            else
            {
                MessageBox.Show("Password should not be empty", "Required password", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chck_ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chck_ShowPass.Checked)
            {
                txtPassword.UseSystemPasswordChar = false;
                txtPassword.PasswordChar = '\0';
            }
            else
            {
                txtPassword.UseSystemPasswordChar = true;
                txtPassword.PasswordChar = '*';
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
