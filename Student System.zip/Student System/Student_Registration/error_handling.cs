﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Student_Registration
{
    internal class error_handling
    {
        //null string 
        public bool notNull(string a)
        {

            if (string.IsNullOrEmpty(a))
            {
                return false;
            }
            else
                return true;
        }
        public bool notNull(string a, string b)
        {

            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b))
            {
                return false;
            }
            else
                return true;
        }

        public bool notNull(string a, string b, string c)
        {

            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b) || string.IsNullOrEmpty(c))
            {
                return false;
            }
            else
                return true;
        }

        // method overloading 
        public bool notNull(string a, string b, string c, string d, string e)
        {

            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b) || string.IsNullOrEmpty(c) || string.IsNullOrEmpty(d) || string.IsNullOrEmpty(e))
            {
                return false;
            }
            else
                return true;
        }
        public bool notNull(string a, string b, string c, string d, string e, string f, string g)
        {

            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b) || string.IsNullOrEmpty(c) || string.IsNullOrEmpty(d) || string.IsNullOrEmpty(e) || string.IsNullOrEmpty(f) || string.IsNullOrEmpty(g))
            {
                return false;
            }
            else
                return true;
        }




        public bool emailChecker(string email)
        {
            if (email.EndsWith("@gmail.com"))
            {
                return true;
            }
            else return false;
        }



        public bool namesChecker(string name)
        {
            int countNC = 0;

            foreach (char a in name)
            {
                if (char.IsDigit(a))
                {
                    countNC++;
                }
            }
            if (countNC == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool contactNumChecker(string contact)
        {
            int countCN = 0;

            foreach (char a in contact)
            {
                if (char.IsDigit(a))
                    countCN++;               
            }
            
              if (countCN == 11) return true;
              else return false;
        }


        //validation of time 
        public bool endAndStartTime(string startTime, string endTime)
        {
            TimeSpan start = TimeSpan.Parse(startTime);
            TimeSpan end = TimeSpan.Parse(endTime);

            // Compare the TimeSpan objects

            if (start >= end)
            {
                return false;
            }
            else
                return true;
        }

        // validation of the string matches the nn:nn format
        public bool IsValidNumberFormat(string input)
        {

            if (input.Length == 5 &&
                char.IsDigit(input[0]) &&
                char.IsDigit(input[1]) &&
                input[2] == ':' &&
                char.IsDigit(input[3]) &&
                char.IsDigit(input[4]))
            {
                return true;
            }
            else return false;



        }

        public bool ptsIsGreaterOrEqual(string pts, string balanced)
        {
            double.TryParse(pts , out double points);
            double.TryParse(balanced, out double Balanced);

            if (points > Balanced)
            {
                return false ;
            }else return true;

        }

        public bool IsNumberz(string number)
        {
            int count  = 0;
            foreach (char a in number)
            {
                if (!char.IsDigit(a))
                {
                     count++; 
                }
            }
            if (count > 0)
            {
                return false;
            }else return true;
        }

        public bool zeroUngSineSent(string sent)
        {
            double.TryParse(sent, out double points);

            if (points == 0)
            {
                return false ;
            }else return true;
        }

        public bool passwordLengthCheck(string pass)
        {
            int countChar = 0;

            foreach (char a in pass)
            {           
                    countChar++;
            }

            if (countChar >= 8) return true;
            else return false;
        }


    }
}
