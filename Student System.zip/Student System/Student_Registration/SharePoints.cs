﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Student_Registration
{
    public partial class SharePoints : Form
    {
        error_handling ER = new error_handling();

        //for raduis button

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
       int nLeftRect, // x-coordinate of upper-left corner
       int nTopRect, // y-coordinate of upper-left corner
       int nRightRect, // x-coordinate of lower-right corner
       int nBottomRect, // y-coordinate of lower-right corner
       int nWidthEllipse, // height of ellipse
       int nHeightEllipse // width of ellipse
    );

        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        public static double points;
        private System.Timers.Timer timer;
        StudentSystem parentForm;
        public SharePoints(StudentSystem parentForm)
        {
            InitializeComponent();
            this.parentForm = parentForm;


            //for raduis button
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            btnSharePoints.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btnSharePoints.Width, btnSharePoints.Height, 5, 5));
            btnCancel.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btnCancel.Width, btnCancel.Height, 5, 5));
            txtBalancePoints.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtBalancePoints.Width, txtBalancePoints.Height, 5, 5));
            txtAccountID.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtAccountID.Width, txtAccountID.Height, 5, 5));
            txtPoints.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtPoints.Width, txtPoints.Height, 5, 5));
            pictureBox1.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, pictureBox1.Width, pictureBox1.Height, 5, 5));
            InitializePoints();
            txtBalancePoints.Text = points.ToString();
        }
        private void SharePoints_Load(object sender, EventArgs e)
        {
        }

        private void btnSharePoints_Click(object sender, EventArgs e)
        {
            if (ER.notNull(txtPoints.Text) && ER.notNull(txtAccountID.Text))
            {
                if (ER.IsNumberz(txtPoints.Text) && ER.IsNumberz(txtAccountID.Text))
                {
                    MySqlConnection conz = new MySqlConnection(constring);
                    conz.Open();

                    string checkquery = "SELECT COUNT(*) FROM signup_tb WHERE std_ID = @id";
                    MySqlCommand cmd0 = new MySqlCommand(checkquery, conz);
                    cmd0.Parameters.AddWithValue("@id", txtAccountID.Text);
                    int count = Convert.ToInt32(cmd0.ExecuteScalar());

                    if (count > 0)
                    {
                        if (ER.ptsIsGreaterOrEqual(txtPoints.Text, txtBalancePoints.Text))
                        {
                            if (ER.zeroUngSineSent(txtPoints.Text))
                            {
                                double recitationPoints = Convert.ToDouble(txtPoints.Text);
                                int ID = Convert.ToInt32(txtAccountID.Text);

                                using (MySqlConnection con = new MySqlConnection(constring))
                                {
                                    con.Open();

                                    // Update the recipient's points
                                    string updateQuery1 = "UPDATE signup_tb SET recitation_pts = recitation_pts + @recitation_pts WHERE std_ID = @std_ID";
                                    using (MySqlCommand cmd = new MySqlCommand(updateQuery1, con))
                                    {
                                        cmd.Parameters.AddWithValue("@std_ID", ID);
                                        cmd.Parameters.AddWithValue("@recitation_pts", recitationPoints);
                                        cmd.ExecuteNonQuery();
                                    }

                                    // Deduct the points from the sender's account
                                    string updateQuery2 = "UPDATE signup_tb SET recitation_pts = recitation_pts - @recitation_pts WHERE std_ID = @sender_ID";
                                    using (MySqlCommand cmd2 = new MySqlCommand(updateQuery2, con))
                                    {
                                        cmd2.Parameters.AddWithValue("@sender_ID", SignIn.student_ID);
                                        cmd2.Parameters.AddWithValue("@recitation_pts", recitationPoints);
                                        cmd2.ExecuteNonQuery();
                                    }
                                }

                                // Update points after transaction
                                InitializePoints();
                                txtBalancePoints.Text = points.ToString();

                                MessageBox.Show("Gift Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("Cannot send 0 balanced", "Insufficient points", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Not enough balance", "Insufficient points", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("No Account Id found", "Invalid ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Cannot proceed", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Fields should not be empty", "Empty field", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void InitializePoints()
        {
            using (MySqlConnection con = new MySqlConnection(constring))
            {
                con.Open();
                string query = "SELECT recitation_pts FROM signup_tb WHERE std_ID = @std_ID";
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);
                    object recitation_pts = cmd.ExecuteScalar();
                    if (recitation_pts != null)
                    {
                        points = Convert.ToDouble(recitation_pts);
                    }
                }
            }

        }


        private void StartTimer()
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000; // 1 second
            timer.Elapsed += OnTimedEvent;
            timer.AutoReset = true;
            timer.Enabled = true;
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            using (MySqlConnection con = new MySqlConnection(constring))
            {
                con.Open();
                string query = "SELECT recitation_pts FROM signup_tb WHERE std_ID = @std_ID";
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);
                    object recitation_pts = cmd.ExecuteScalar();
                    if (recitation_pts != null)
                    {
                        double newPoints = Convert.ToDouble(recitation_pts);
                        if (newPoints != points)
                        {
                            points = newPoints;
                            UpdatePointsLabel(newPoints);
                        }

                    }
                }
            }
        }

        private void UpdatePointsLabel(double newPoints)
        {
            // Ensure that the label is updated on the UI thread
            if (txtBalancePoints.InvokeRequired)
            {
                txtBalancePoints.Invoke(new Action(() => txtBalancePoints.Text = $"Points:{newPoints}"));
            }
            else
            {
                txtBalancePoints.Text = $"Points:{newPoints}";
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("How many points you want to share", "Share information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
