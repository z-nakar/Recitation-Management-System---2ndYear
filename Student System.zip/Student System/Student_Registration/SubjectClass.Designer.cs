﻿namespace Student_Registration
{
    partial class SubjectClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubjectClass));
            label_life = new Label();
            label_greet = new Label();
            btnParticipate = new Button();
            label_Points = new Label();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            progressBar_life3 = new CustomProgressBar();
            progressBar_life2 = new CustomProgressBar();
            progressBar_life1 = new CustomProgressBar();
            txtLife = new TextBox();
            panel2 = new Panel();
            pictureBox4 = new PictureBox();
            txtPoints = new TextBox();
            back = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)back).BeginInit();
            SuspendLayout();
            // 
            // label_life
            // 
            label_life.AutoSize = true;
            label_life.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label_life.Location = new Point(40, 9);
            label_life.Name = "label_life";
            label_life.Size = new Size(44, 20);
            label_life.TabIndex = 1;
            label_life.Text = "Life:";
            // 
            // label_greet
            // 
            label_greet.AutoSize = true;
            label_greet.BackColor = Color.Transparent;
            label_greet.FlatStyle = FlatStyle.Flat;
            label_greet.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label_greet.ForeColor = Color.Black;
            label_greet.Location = new Point(76, 101);
            label_greet.Name = "label_greet";
            label_greet.Size = new Size(197, 45);
            label_greet.TabIndex = 2;
            label_greet.Text = "Welcome To";
            label_greet.Click += label_greet_Click;
            // 
            // btnParticipate
            // 
            btnParticipate.BackColor = Color.Maroon;
            btnParticipate.FlatAppearance.BorderColor = Color.White;
            btnParticipate.FlatStyle = FlatStyle.Flat;
            btnParticipate.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnParticipate.ForeColor = Color.White;
            btnParticipate.Location = new Point(94, 339);
            btnParticipate.Name = "btnParticipate";
            btnParticipate.Size = new Size(337, 33);
            btnParticipate.TabIndex = 3;
            btnParticipate.Text = "Participate";
            btnParticipate.UseVisualStyleBackColor = false;
            btnParticipate.Click += btnParticipate_Click;
            // 
            // label_Points
            // 
            label_Points.AutoSize = true;
            label_Points.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label_Points.Location = new Point(40, 7);
            label_Points.Name = "label_Points";
            label_Points.Size = new Size(64, 20);
            label_Points.TabIndex = 140;
            label_Points.Text = "Points:";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(37, 33);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 139;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(37, 33);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 138;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(317, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(20, 20);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 142;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(progressBar_life3);
            panel1.Controls.Add(progressBar_life2);
            panel1.Controls.Add(progressBar_life1);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(label_life);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(txtLife);
            panel1.Location = new Point(94, 194);
            panel1.Name = "panel1";
            panel1.Size = new Size(340, 35);
            panel1.TabIndex = 143;
            // 
            // progressBar_life3
            // 
            progressBar_life3.Location = new Point(138, 16);
            progressBar_life3.Name = "progressBar_life3";
            progressBar_life3.ProgressBarColor = Color.Red;
            progressBar_life3.Size = new Size(27, 10);
            progressBar_life3.TabIndex = 173;
            progressBar_life3.Value = 100;
            // 
            // progressBar_life2
            // 
            progressBar_life2.Location = new Point(193, 16);
            progressBar_life2.Name = "progressBar_life2";
            progressBar_life2.ProgressBarColor = Color.Red;
            progressBar_life2.Size = new Size(28, 10);
            progressBar_life2.TabIndex = 172;
            progressBar_life2.Value = 100;
            // 
            // progressBar_life1
            // 
            progressBar_life1.Location = new Point(246, 16);
            progressBar_life1.Name = "progressBar_life1";
            progressBar_life1.ProgressBarColor = Color.Red;
            progressBar_life1.Size = new Size(28, 10);
            progressBar_life1.TabIndex = 171;
            progressBar_life1.Value = 100;
            // 
            // txtLife
            // 
            txtLife.BorderStyle = BorderStyle.None;
            txtLife.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtLife.Location = new Point(97, 8);
            txtLife.Name = "txtLife";
            txtLife.Size = new Size(240, 19);
            txtLife.TabIndex = 144;
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox4);
            panel2.Controls.Add(label_Points);
            panel2.Controls.Add(pictureBox3);
            panel2.Controls.Add(txtPoints);
            panel2.Location = new Point(94, 274);
            panel2.Name = "panel2";
            panel2.Size = new Size(340, 35);
            panel2.TabIndex = 144;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(317, 10);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(20, 20);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 142;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // txtPoints
            // 
            txtPoints.BorderStyle = BorderStyle.None;
            txtPoints.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPoints.Location = new Point(97, 8);
            txtPoints.Name = "txtPoints";
            txtPoints.Size = new Size(240, 19);
            txtPoints.TabIndex = 144;
            txtPoints.TextChanged += txtPoints_TextChanged;
            // 
            // back
            // 
            back.BackColor = Color.Transparent;
            back.Image = (Image)resources.GetObject("back.Image");
            back.Location = new Point(513, 26);
            back.Name = "back";
            back.Size = new Size(21, 18);
            back.SizeMode = PictureBoxSizeMode.StretchImage;
            back.TabIndex = 170;
            back.TabStop = false;
            back.Click += back_Click;
            // 
            // SubjectClass
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(548, 503);
            Controls.Add(back);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(btnParticipate);
            Controls.Add(label_greet);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "SubjectClass";
            Text = "SubjectClass";
            Load += SubjectClass_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)back).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion
        private Label label_life;
        private Label label_greet;
        private Button btnParticipate;
        private Label label_Points;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Panel panel1;
        private TextBox txtLife;
        private Panel panel2;
        private TextBox txtPoints;
        private PictureBox pictureBox4;
        private PictureBox back;
        private CustomProgressBar progressBar_life1;
        private CustomProgressBar progressBar_life2;
        private CustomProgressBar progressBar_life3;
    }
}