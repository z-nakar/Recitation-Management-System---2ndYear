﻿namespace Student_Registration
{
    partial class StudentSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentSystem));
            panel_main2 = new Panel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            btnGiftPoints = new Button();
            btn_SI = new Button();
            btn_ES = new Button();
            btnLogOut = new Button();
            lbl_pts = new Label();
            pictureBox3 = new PictureBox();
            btn_SCL = new Button();
            panel_main2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel_main2
            // 
            panel_main2.BackgroundImage = (Image)resources.GetObject("panel_main2.BackgroundImage");
            panel_main2.Controls.Add(label4);
            panel_main2.Controls.Add(label3);
            panel_main2.Controls.Add(label2);
            panel_main2.Controls.Add(label1);
            panel_main2.Controls.Add(pictureBox5);
            panel_main2.Controls.Add(pictureBox4);
            panel_main2.Controls.Add(btnGiftPoints);
            panel_main2.Controls.Add(btn_SI);
            panel_main2.Controls.Add(btn_ES);
            panel_main2.Controls.Add(btnLogOut);
            panel_main2.Controls.Add(lbl_pts);
            panel_main2.Controls.Add(pictureBox3);
            panel_main2.Controls.Add(btn_SCL);
            panel_main2.Location = new Point(-8, 0);
            panel_main2.Margin = new Padding(3, 2, 3, 2);
            panel_main2.Name = "panel_main2";
            panel_main2.Size = new Size(544, 495);
            panel_main2.TabIndex = 20;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(166, 144);
            label4.Name = "label4";
            label4.Size = new Size(230, 39);
            label4.TabIndex = 35;
            label4.Text = "Recite Quest";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Maroon;
            label3.ForeColor = Color.White;
            label3.Location = new Point(123, 434);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 34;
            label3.Text = "View Details";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Maroon;
            label2.ForeColor = Color.White;
            label2.Location = new Point(123, 343);
            label2.Name = "label2";
            label2.Size = new Size(70, 15);
            label2.TabIndex = 33;
            label2.Text = "View Details";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Maroon;
            label1.ForeColor = Color.White;
            label1.Location = new Point(123, 256);
            label1.Name = "label1";
            label1.Size = new Size(70, 15);
            label1.TabIndex = 32;
            label1.Text = "View Details";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.Maroon;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(384, 407);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(50, 50);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 31;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Maroon;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(383, 318);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(50, 50);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 30;
            pictureBox4.TabStop = false;
            // 
            // btnGiftPoints
            // 
            btnGiftPoints.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnGiftPoints.Location = new Point(456, 71);
            btnGiftPoints.Name = "btnGiftPoints";
            btnGiftPoints.Size = new Size(75, 23);
            btnGiftPoints.TabIndex = 28;
            btnGiftPoints.Text = "Gift Points";
            btnGiftPoints.UseVisualStyleBackColor = true;
            btnGiftPoints.Click += btnGiftPoints_Click;
            // 
            // btn_SI
            // 
            btn_SI.BackColor = Color.Maroon;
            btn_SI.FlatAppearance.BorderColor = Color.White;
            btn_SI.FlatAppearance.BorderSize = 0;
            btn_SI.FlatStyle = FlatStyle.Flat;
            btn_SI.Font = new Font("Franklin Gothic Medium Cond", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_SI.ForeColor = Color.White;
            btn_SI.Location = new Point(116, 403);
            btn_SI.Margin = new Padding(3, 2, 3, 2);
            btn_SI.Name = "btn_SI";
            btn_SI.Size = new Size(319, 61);
            btn_SI.TabIndex = 26;
            btn_SI.Text = "Student Information";
            btn_SI.TextAlign = ContentAlignment.TopLeft;
            btn_SI.UseVisualStyleBackColor = false;
            btn_SI.Click += btn_SI_Click;
            // 
            // btn_ES
            // 
            btn_ES.BackColor = Color.Maroon;
            btn_ES.FlatAppearance.BorderColor = Color.White;
            btn_ES.FlatAppearance.BorderSize = 0;
            btn_ES.FlatStyle = FlatStyle.Flat;
            btn_ES.Font = new Font("Franklin Gothic Medium Cond", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_ES.ForeColor = Color.White;
            btn_ES.Location = new Point(116, 314);
            btn_ES.Margin = new Padding(3, 2, 3, 2);
            btn_ES.Name = "btn_ES";
            btn_ES.Size = new Size(319, 61);
            btn_ES.TabIndex = 25;
            btn_ES.Text = "Enrolled Subject";
            btn_ES.TextAlign = ContentAlignment.TopLeft;
            btn_ES.UseVisualStyleBackColor = false;
            btn_ES.Click += btn_ES_Click;
            // 
            // btnLogOut
            // 
            btnLogOut.BackColor = Color.Transparent;
            btnLogOut.FlatAppearance.BorderColor = Color.White;
            btnLogOut.FlatAppearance.BorderSize = 0;
            btnLogOut.FlatStyle = FlatStyle.Flat;
            btnLogOut.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnLogOut.ForeColor = Color.White;
            btnLogOut.Location = new Point(481, 26);
            btnLogOut.Margin = new Padding(3, 2, 3, 2);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(73, 29);
            btnLogOut.TabIndex = 23;
            btnLogOut.Text = "Log Out";
            btnLogOut.UseVisualStyleBackColor = false;
            btnLogOut.Click += btnLogOut_Click;
            // 
            // lbl_pts
            // 
            lbl_pts.AutoSize = true;
            lbl_pts.BackColor = Color.Maroon;
            lbl_pts.Font = new Font("Microsoft Tai Le", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_pts.ForeColor = Color.White;
            lbl_pts.Location = new Point(14, 76);
            lbl_pts.Name = "lbl_pts";
            lbl_pts.Size = new Size(46, 14);
            lbl_pts.TabIndex = 22;
            lbl_pts.Text = "Points: ";
            lbl_pts.Click += lbl_pts_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.Maroon;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(381, 229);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(50, 50);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 29;
            pictureBox3.TabStop = false;
            // 
            // btn_SCL
            // 
            btn_SCL.BackColor = Color.Maroon;
            btn_SCL.FlatAppearance.BorderColor = Color.White;
            btn_SCL.FlatAppearance.BorderSize = 0;
            btn_SCL.FlatStyle = FlatStyle.Flat;
            btn_SCL.Font = new Font("Franklin Gothic Medium Cond", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btn_SCL.ForeColor = Color.White;
            btn_SCL.Location = new Point(116, 225);
            btn_SCL.Margin = new Padding(3, 2, 3, 2);
            btn_SCL.Name = "btn_SCL";
            btn_SCL.Size = new Size(319, 61);
            btn_SCL.TabIndex = 24;
            btn_SCL.Text = "Subject";
            btn_SCL.TextAlign = ContentAlignment.TopLeft;
            btn_SCL.UseVisualStyleBackColor = false;
            btn_SCL.Click += btn_SCL_Click_1;
            // 
            // StudentSystem
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(536, 506);
            Controls.Add(panel_main2);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "StudentSystem";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "StudentSystem";
            Load += StudentSystem_Load;
            panel_main2.ResumeLayout(false);
            panel_main2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel_main2;
        private Label lbl_pts;
        private Button btn_SI;
        private Button btn_ES;
        private Button btn_SCL;
        private Button btnLogOut;
        private Button btnGiftPoints;
        private PictureBox pictureBox3;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
    }
}