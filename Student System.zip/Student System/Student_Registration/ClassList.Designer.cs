﻿namespace Student_Registration
{
    partial class ClassList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClassList));
            panel_classSubject = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            panel_main = new Panel();
            undo = new PictureBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            panel_classSubject.SuspendLayout();
            panel_main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)undo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel_classSubject
            // 
            panel_classSubject.Controls.Add(panel5);
            panel_classSubject.Controls.Add(panel6);
            panel_classSubject.Controls.Add(panel7);
            panel_classSubject.Controls.Add(panel8);
            panel_classSubject.Location = new Point(29, 137);
            panel_classSubject.Margin = new Padding(3, 2, 3, 2);
            panel_classSubject.Name = "panel_classSubject";
            panel_classSubject.Size = new Size(474, 341);
            panel_classSubject.TabIndex = 117;
            panel_classSubject.Paint += panel_classSubject_Paint;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(1, 0);
            panel5.Margin = new Padding(3, 2, 3, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(472, 1);
            panel5.TabIndex = 0;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Black;
            panel6.Dock = DockStyle.Left;
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(3, 2, 3, 2);
            panel6.Name = "panel6";
            panel6.Size = new Size(1, 340);
            panel6.TabIndex = 1;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Black;
            panel7.Dock = DockStyle.Right;
            panel7.Location = new Point(473, 0);
            panel7.Margin = new Padding(3, 2, 3, 2);
            panel7.Name = "panel7";
            panel7.Size = new Size(1, 340);
            panel7.TabIndex = 2;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Black;
            panel8.Dock = DockStyle.Bottom;
            panel8.Location = new Point(0, 340);
            panel8.Margin = new Padding(3, 2, 3, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(474, 1);
            panel8.TabIndex = 3;
            // 
            // panel_main
            // 
            panel_main.BackgroundImage = (Image)resources.GetObject("panel_main.BackgroundImage");
            panel_main.Controls.Add(undo);
            panel_main.Controls.Add(pictureBox1);
            panel_main.Controls.Add(panel_classSubject);
            panel_main.Controls.Add(label1);
            panel_main.Location = new Point(3, 1);
            panel_main.Margin = new Padding(3, 2, 3, 2);
            panel_main.Name = "panel_main";
            panel_main.Size = new Size(547, 504);
            panel_main.TabIndex = 1;
            panel_main.Paint += panel_main_Paint;
            // 
            // undo
            // 
            undo.BackColor = Color.Transparent;
            undo.Image = (Image)resources.GetObject("undo.Image");
            undo.Location = new Point(510, 29);
            undo.Name = "undo";
            undo.Size = new Size(21, 18);
            undo.SizeMode = PictureBoxSizeMode.StretchImage;
            undo.TabIndex = 168;
            undo.TabStop = false;
            undo.Click += undo_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 67);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(87, 68);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(117, 80);
            label1.Name = "label1";
            label1.Size = new Size(152, 45);
            label1.TabIndex = 11;
            label1.Text = "SUBJECT";
            // 
            // ClassList
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(544, 511);
            Controls.Add(panel_main);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ClassList";
            StartPosition = FormStartPosition.CenterParent;
            Text = "ClassList";
            panel_classSubject.ResumeLayout(false);
            panel_main.ResumeLayout(false);
            panel_main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)undo).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Panel panel3;
        private TextBox txt_Search;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private Label lbl_classSub;
        private Panel panel_classSubject;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel_main;
        private Label label1;
        private PictureBox undo;
    }
}