﻿namespace Student_Registration
{
    partial class Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Password));
            txtSubCode = new TextBox();
            txtPassword = new TextBox();
            btnConfirmPassword = new Button();
            lblSubject_code = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox7 = new PictureBox();
            chck_ShowPass = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            SuspendLayout();
            // 
            // txtSubCode
            // 
            txtSubCode.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtSubCode.Location = new Point(145, 214);
            txtSubCode.Name = "txtSubCode";
            txtSubCode.ReadOnly = true;
            txtSubCode.Size = new Size(259, 26);
            txtSubCode.TabIndex = 1;
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.Location = new Point(145, 298);
            txtPassword.Name = "txtPassword";
            txtPassword.PlaceholderText = "********";
            txtPassword.Size = new Size(259, 26);
            txtPassword.TabIndex = 2;
            txtPassword.UseSystemPasswordChar = true;
            // 
            // btnConfirmPassword
            // 
            btnConfirmPassword.BackColor = Color.Maroon;
            btnConfirmPassword.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnConfirmPassword.ForeColor = Color.White;
            btnConfirmPassword.Location = new Point(145, 387);
            btnConfirmPassword.Name = "btnConfirmPassword";
            btnConfirmPassword.Size = new Size(259, 38);
            btnConfirmPassword.TabIndex = 3;
            btnConfirmPassword.Text = "Confirm";
            btnConfirmPassword.UseVisualStyleBackColor = false;
            btnConfirmPassword.Click += btnConfirmPassword_Click;
            // 
            // lblSubject_code
            // 
            lblSubject_code.AutoSize = true;
            lblSubject_code.BackColor = Color.White;
            lblSubject_code.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            lblSubject_code.Location = new Point(262, 104);
            lblSubject_code.Name = "lblSubject_code";
            lblSubject_code.Size = new Size(108, 31);
            lblSubject_code.TabIndex = 6;
            lblSubject_code.Text = "CLASS";
            lblSubject_code.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(119, 180);
            label2.Name = "label2";
            label2.Size = new Size(117, 20);
            label2.TabIndex = 7;
            label2.Text = "Subject Code";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(119, 264);
            label3.Name = "label3";
            label3.Size = new Size(135, 20);
            label3.TabIndex = 8;
            label3.Text = "Class Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Microsoft Sans Serif", 20.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(163, 104);
            label4.Name = "label4";
            label4.Size = new Size(81, 31);
            label4.TabIndex = 10;
            label4.Text = "JOIN";
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.Transparent;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(507, 26);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(21, 18);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 189;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // chck_ShowPass
            // 
            chck_ShowPass.AutoSize = true;
            chck_ShowPass.BackColor = Color.White;
            chck_ShowPass.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            chck_ShowPass.ForeColor = Color.Gray;
            chck_ShowPass.Location = new Point(282, 340);
            chck_ShowPass.Margin = new Padding(3, 2, 3, 2);
            chck_ShowPass.Name = "chck_ShowPass";
            chck_ShowPass.Size = new Size(122, 20);
            chck_ShowPass.TabIndex = 190;
            chck_ShowPass.TabStop = false;
            chck_ShowPass.Text = "Show Password";
            chck_ShowPass.UseVisualStyleBackColor = false;
            chck_ShowPass.CheckedChanged += chck_ShowPass_CheckedChanged;
            // 
            // Password
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(539, 467);
            Controls.Add(chck_ShowPass);
            Controls.Add(pictureBox7);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(lblSubject_code);
            Controls.Add(btnConfirmPassword);
            Controls.Add(txtPassword);
            Controls.Add(txtSubCode);
            Name = "Password";
            Text = "Password";
            Load += Password_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtSubCode;
        private TextBox txtPassword;
        private Button btnConfirmPassword;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox7;
        private Label lblSubject_code;
        private CheckBox chck_ShowPass;
    }
}