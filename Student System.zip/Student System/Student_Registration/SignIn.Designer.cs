﻿namespace Student_Registration
{
    partial class SignIn
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignIn));
            panel_main = new Panel();
            label4 = new Label();
            label3 = new Label();
            panel_logoSide = new Panel();
            pic_Logo = new PictureBox();
            lbl_Registration = new Label();
            lbl_ProfApp = new Label();
            panel__EmailAdd = new Panel();
            pic_username = new PictureBox();
            txt_UserName = new TextBox();
            label2 = new Label();
            btnForgetPass = new Button();
            btn_LogIn = new Button();
            chck_ShowPass = new CheckBox();
            panel_Password = new Panel();
            txt_Password = new TextBox();
            pic_pass = new PictureBox();
            btnSignUp = new Button();
            panel_main.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_Logo).BeginInit();
            panel__EmailAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_username).BeginInit();
            panel_Password.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_pass).BeginInit();
            SuspendLayout();
            // 
            // panel_main
            // 
            panel_main.BackColor = Color.White;
            panel_main.Controls.Add(label4);
            panel_main.Controls.Add(label3);
            panel_main.Controls.Add(panel_logoSide);
            panel_main.Controls.Add(pic_Logo);
            panel_main.Controls.Add(lbl_Registration);
            panel_main.Controls.Add(lbl_ProfApp);
            panel_main.Controls.Add(panel__EmailAdd);
            panel_main.Controls.Add(label2);
            panel_main.Controls.Add(btnForgetPass);
            panel_main.Controls.Add(btn_LogIn);
            panel_main.Controls.Add(chck_ShowPass);
            panel_main.Controls.Add(panel_Password);
            panel_main.Controls.Add(btnSignUp);
            panel_main.Dock = DockStyle.Fill;
            panel_main.Location = new Point(0, 0);
            panel_main.Margin = new Padding(3, 2, 3, 2);
            panel_main.Name = "panel_main";
            panel_main.Size = new Size(929, 434);
            panel_main.TabIndex = 170;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Consolas", 6.75F, FontStyle.Italic, GraphicsUnit.Point);
            label4.ForeColor = Color.DarkGoldenrod;
            label4.Location = new Point(495, 39);
            label4.Name = "label4";
            label4.Size = new Size(165, 10);
            label4.TabIndex = 168;
            label4.Text = "\"The Country's 1st PolytechnicU\"";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Consolas", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(495, 22);
            label3.Name = "label3";
            label3.Size = new Size(294, 14);
            label3.TabIndex = 167;
            label3.Text = "Polytechnic University of the Philippines";
            // 
            // panel_logoSide
            // 
            panel_logoSide.BackgroundImage = (Image)resources.GetObject("panel_logoSide.BackgroundImage");
            panel_logoSide.Location = new Point(0, 0);
            panel_logoSide.Margin = new Padding(3, 2, 3, 2);
            panel_logoSide.Name = "panel_logoSide";
            panel_logoSide.Size = new Size(400, 438);
            panel_logoSide.TabIndex = 160;
            // 
            // pic_Logo
            // 
            pic_Logo.Image = (Image)resources.GetObject("pic_Logo.Image");
            pic_Logo.Location = new Point(426, 11);
            pic_Logo.Margin = new Padding(3, 2, 3, 2);
            pic_Logo.Name = "pic_Logo";
            pic_Logo.Size = new Size(79, 68);
            pic_Logo.SizeMode = PictureBoxSizeMode.Zoom;
            pic_Logo.TabIndex = 166;
            pic_Logo.TabStop = false;
            // 
            // lbl_Registration
            // 
            lbl_Registration.AutoSize = true;
            lbl_Registration.BackColor = Color.Transparent;
            lbl_Registration.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_Registration.ForeColor = Color.Black;
            lbl_Registration.Location = new Point(654, 135);
            lbl_Registration.Name = "lbl_Registration";
            lbl_Registration.Size = new Size(67, 24);
            lbl_Registration.TabIndex = 162;
            lbl_Registration.Text = "LOGIN";
            // 
            // lbl_ProfApp
            // 
            lbl_ProfApp.AutoSize = true;
            lbl_ProfApp.BackColor = Color.Transparent;
            lbl_ProfApp.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_ProfApp.ForeColor = Color.Maroon;
            lbl_ProfApp.Location = new Point(586, 98);
            lbl_ProfApp.Name = "lbl_ProfApp";
            lbl_ProfApp.Size = new Size(217, 25);
            lbl_ProfApp.TabIndex = 161;
            lbl_ProfApp.Text = "Student Application";
            lbl_ProfApp.Click += lbl_ProfApp_Click;
            // 
            // panel__EmailAdd
            // 
            panel__EmailAdd.BackColor = Color.White;
            panel__EmailAdd.Controls.Add(pic_username);
            panel__EmailAdd.Controls.Add(txt_UserName);
            panel__EmailAdd.ImeMode = ImeMode.Off;
            panel__EmailAdd.Location = new Point(523, 180);
            panel__EmailAdd.Margin = new Padding(3, 2, 3, 2);
            panel__EmailAdd.Name = "panel__EmailAdd";
            panel__EmailAdd.Size = new Size(322, 34);
            panel__EmailAdd.TabIndex = 158;
            // 
            // pic_username
            // 
            pic_username.Image = (Image)resources.GetObject("pic_username.Image");
            pic_username.Location = new Point(6, 8);
            pic_username.Margin = new Padding(3, 2, 3, 2);
            pic_username.Name = "pic_username";
            pic_username.Size = new Size(22, 19);
            pic_username.SizeMode = PictureBoxSizeMode.Zoom;
            pic_username.TabIndex = 9;
            pic_username.TabStop = false;
            // 
            // txt_UserName
            // 
            txt_UserName.BackColor = Color.WhiteSmoke;
            txt_UserName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_UserName.Location = new Point(33, 4);
            txt_UserName.Margin = new Padding(3, 2, 3, 2);
            txt_UserName.Multiline = true;
            txt_UserName.Name = "txt_UserName";
            txt_UserName.PlaceholderText = "Email";
            txt_UserName.Size = new Size(284, 26);
            txt_UserName.TabIndex = 166;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(606, 399);
            label2.Name = "label2";
            label2.Size = new Size(122, 13);
            label2.TabIndex = 164;
            label2.Text = "Don't have an account?";
            // 
            // btnForgetPass
            // 
            btnForgetPass.BackColor = Color.White;
            btnForgetPass.FlatAppearance.BorderSize = 0;
            btnForgetPass.FlatStyle = FlatStyle.Flat;
            btnForgetPass.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnForgetPass.ForeColor = Color.Maroon;
            btnForgetPass.Location = new Point(730, 288);
            btnForgetPass.Margin = new Padding(3, 2, 3, 2);
            btnForgetPass.Name = "btnForgetPass";
            btnForgetPass.Size = new Size(119, 28);
            btnForgetPass.TabIndex = 163;
            btnForgetPass.TabStop = false;
            btnForgetPass.Text = "&Forget Password";
            btnForgetPass.UseVisualStyleBackColor = false;
            btnForgetPass.Click += btnForgetPass_Click;
            // 
            // btn_LogIn
            // 
            btn_LogIn.BackColor = Color.Maroon;
            btn_LogIn.FlatAppearance.BorderSize = 0;
            btn_LogIn.FlatStyle = FlatStyle.Flat;
            btn_LogIn.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_LogIn.ForeColor = Color.White;
            btn_LogIn.Location = new Point(523, 352);
            btn_LogIn.Margin = new Padding(3, 2, 3, 2);
            btn_LogIn.Name = "btn_LogIn";
            btn_LogIn.Size = new Size(322, 32);
            btn_LogIn.TabIndex = 0;
            btn_LogIn.Text = "&Log In";
            btn_LogIn.UseVisualStyleBackColor = false;
            btn_LogIn.Click += btn_LogIn_Click;
            // 
            // chck_ShowPass
            // 
            chck_ShowPass.AutoSize = true;
            chck_ShowPass.BackColor = Color.White;
            chck_ShowPass.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            chck_ShowPass.ForeColor = Color.Gray;
            chck_ShowPass.Location = new Point(556, 296);
            chck_ShowPass.Margin = new Padding(3, 2, 3, 2);
            chck_ShowPass.Name = "chck_ShowPass";
            chck_ShowPass.Size = new Size(102, 17);
            chck_ShowPass.TabIndex = 156;
            chck_ShowPass.TabStop = false;
            chck_ShowPass.Text = "Show Password";
            chck_ShowPass.UseVisualStyleBackColor = false;
            chck_ShowPass.CheckedChanged += chck_ShowPass_CheckedChanged;
            // 
            // panel_Password
            // 
            panel_Password.BackColor = Color.White;
            panel_Password.Controls.Add(txt_Password);
            panel_Password.Controls.Add(pic_pass);
            panel_Password.Location = new Point(523, 234);
            panel_Password.Margin = new Padding(3, 2, 3, 2);
            panel_Password.Name = "panel_Password";
            panel_Password.Size = new Size(322, 34);
            panel_Password.TabIndex = 1;
            // 
            // txt_Password
            // 
            txt_Password.BackColor = Color.WhiteSmoke;
            txt_Password.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_Password.Location = new Point(33, 6);
            txt_Password.Name = "txt_Password";
            txt_Password.PasswordChar = '*';
            txt_Password.PlaceholderText = "Password";
            txt_Password.Size = new Size(284, 26);
            txt_Password.TabIndex = 167;
            txt_Password.UseSystemPasswordChar = true;
            // 
            // pic_pass
            // 
            pic_pass.Image = (Image)resources.GetObject("pic_pass.Image");
            pic_pass.Location = new Point(5, 8);
            pic_pass.Margin = new Padding(3, 2, 3, 2);
            pic_pass.Name = "pic_pass";
            pic_pass.Size = new Size(22, 19);
            pic_pass.SizeMode = PictureBoxSizeMode.Zoom;
            pic_pass.TabIndex = 8;
            pic_pass.TabStop = false;
            // 
            // btnSignUp
            // 
            btnSignUp.BackColor = Color.White;
            btnSignUp.FlatAppearance.BorderSize = 0;
            btnSignUp.FlatStyle = FlatStyle.Flat;
            btnSignUp.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSignUp.ForeColor = Color.Maroon;
            btnSignUp.Location = new Point(725, 395);
            btnSignUp.Margin = new Padding(3, 2, 3, 2);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.Size = new Size(57, 28);
            btnSignUp.TabIndex = 0;
            btnSignUp.TabStop = false;
            btnSignUp.Text = "Sign Up";
            btnSignUp.TextAlign = ContentAlignment.MiddleLeft;
            btnSignUp.UseVisualStyleBackColor = false;
            btnSignUp.Click += btnSignUp_Click_1;
            // 
            // SignIn
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(929, 434);
            Controls.Add(panel_main);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "SignIn";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Log In";
            Load += SignIn_Load;
            panel_main.ResumeLayout(false);
            panel_main.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_Logo).EndInit();
            panel__EmailAdd.ResumeLayout(false);
            panel__EmailAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_username).EndInit();
            panel_Password.ResumeLayout(false);
            panel_Password.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_pass).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel_main;
        private Panel panel_logoSide;
        private PictureBox pic_Logo;
        private Label lbl_Registration;
        private Panel panel__EmailAdd;
        private PictureBox pic_username;
        private TextBox txt_UserName;
        private Label label2;
        private Button btnForgetPass;
        private Button btn_LogIn;
        private CheckBox chck_ShowPass;
        private Panel panel_Password;
        private PictureBox pic_pass;
        private Button btnSignUp;
        private Label lbl_ProfApp;
        private TextBox txt_Password;
        private Label label4;
        private Label label3;
    }
}