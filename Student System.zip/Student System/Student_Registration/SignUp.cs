﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Student_Registration
{
    public partial class SignUp : Form
    {

        error_handling ER = new error_handling();
        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        SignIn si;

        public SignUp(SignIn si)
        {
            InitializeComponent();
            this.si = si;
        }

        private void SignUp_Load(object sender, EventArgs e)
        {


        }




        private void btnSignIn_Click(object sender, EventArgs e)
        {
            si.OpenChildForm(this);
        }

        private void lbl_StudentApp_Click(object sender, EventArgs e)
        {

        }

        private void btn_SignUp_Click(object sender, EventArgs e)
        {
            //empty ?
            if (ER.notNull(txt_FN.Text, txt_LN.Text, txt_MN.Text, txtContact.Text, txtEmail.Text, txt_Pass.Text, txt_CPass.Text))
            {   //name containing digits? 
                if (ER.namesChecker(txt_FN.Text) && ER.namesChecker(txt_LN.Text) && ER.namesChecker(txt_MN.Text))
                {       //contact checker 
                    if (ER.contactNumChecker(txtContact.Text))
                    {
                        if (ER.emailChecker(txtEmail.Text))
                        {
                            if (ER.passwordLengthCheck(txt_Pass.Text))
                            {                        
                                using (MySqlConnection conn = new MySqlConnection(constring))
                                {
                                    conn.Open();
                                    string query = "INSERT INTO signup_tb (first_name, last_name, email_, password_, contact, middle_name) " +
                                        "VALUES (@first_name, @last_name, @email, @_password, @contact, @middle_name)";
                                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                                    {

                                        if (txt_Pass.Text.Equals(txt_CPass.Text))
                                        {
                                            cmd.Parameters.AddWithValue("@first_name", txt_FN.Text);
                                            cmd.Parameters.AddWithValue("@last_name", txt_LN.Text);
                                            cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                                            cmd.Parameters.AddWithValue("@_password", txt_Pass.Text);
                                            cmd.Parameters.AddWithValue("@contact", txtContact.Text);
                                            cmd.Parameters.AddWithValue("@middle_name", txt_MN.Text);
                                            cmd.ExecuteNonQuery();
                                            MessageBox.Show("Sign up succesfully", "Sign Up Successfully!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                            this.Close();
                                        }
                                        else
                                        {

                                            MessageBox.Show("Password does not match", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        }
                                    }
                                }
                            } else MessageBox.Show("Password must be atleast 8", "Invalid email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else MessageBox.Show("Email must end with \"@gmail.com\" ", "Invalid email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else MessageBox.Show("Contact number must be 11 digits and does not contains character", "Invalid contact number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("Names must not contains numeric character", "Invalid name", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else MessageBox.Show("Fields should not be empty", "Empty field", MessageBoxButtons.OK, MessageBoxIcon.Error);


        }

        private void chck_ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chck_ShowPass.Checked)
            {
                txt_Pass.UseSystemPasswordChar = false;
                txt_CPass.UseSystemPasswordChar = false;

                txt_Pass.PasswordChar = '\0'; // Clear any custom password character
                txt_CPass.PasswordChar = '\0';
            }
            else
            {
                txt_Pass.UseSystemPasswordChar = true;
                txt_CPass.UseSystemPasswordChar = true;

                txt_Pass.PasswordChar = '*'; // Set the desired masking character, usually '*'
                txt_CPass.PasswordChar = '*';
            }
        }

        private void txt_Pass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
