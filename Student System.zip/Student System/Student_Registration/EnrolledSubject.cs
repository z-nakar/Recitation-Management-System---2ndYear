﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Student_Registration
{
    public partial class EnrolledSubject : Form
    {
        //for raduis button

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
       int nLeftRect, // x-coordinate of upper-left corner
       int nTopRect, // y-coordinate of upper-left corner
       int nRightRect, // x-coordinate of lower-right corner
       int nBottomRect, // y-coordinate of lower-right corner
       int nWidthEllipse, // height of ellipse
       int nHeightEllipse // width of ellipse
    );




        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        string subjectCode;
        int lifePoints;
        private System.Windows.Forms.Timer timer;
        private HashSet<string> existingButtons = new HashSet<string>();
        private StudentSystem parentForm;

        public EnrolledSubject(StudentSystem parentForm)
        {
            InitializeComponent();
            this.parentForm = parentForm;
            LoadInitialButtons();
            InitializeTimer();


            //for raduis button
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            panel_class.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, panel_class.Width, panel_class.Height, 5, 5));
        }


        private void EnrolledSubject_Load(object sender, EventArgs e)
        {

        }

        private void LoadInitialButtons()
        {
            using (MySqlConnection con = new MySqlConnection(constring))
            {
                con.Open();
                string query = "SELECT subj_code, life_points from lifepoints_tb WHERE std_ID = @ID";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@ID", SignIn.student_ID);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    subjectCode = reader["subj_code"].ToString();
                    int lifePoints = Convert.ToInt32(reader["life_points"]);
                    CreateDynamicButton(subjectCode, lifePoints);
                    existingButtons.Add(subjectCode);
                }

                reader.Close();
            }
        }

        private void InitializeTimer()
        {
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 3000; // Set interval to 3 seconds (3000 milliseconds)
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                conn.Open();
                string query = "SELECT subj_code, life_points from lifepoints_tb WHERE std_ID = @ID";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", SignIn.student_ID);
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string subj_code = reader["subj_code"].ToString();
                    int life_points = Convert.ToInt32(reader["life_points"]);

                    if (!existingButtons.Contains(subj_code))
                    {
                        CreateDynamicButton(subj_code, life_points);
                        existingButtons.Add(subj_code);
                    }
                }

                reader.Close();
            }
        }

        void CreateDynamicButton(string class_name, int life_points)
        {
            Button dynamicButton = new Button(); // Create a new instance of Button
            dynamicButton.Dock = DockStyle.Top; // Adjust the DockStyle as needed

            dynamicButton.Enabled = true;
            dynamicButton.Text = class_name; // Set the text of the button
            dynamicButton.Tag = life_points; // Store life_points in the Tag property
            dynamicButton.Font = new Font("Microsoft Sans Serif", 12, FontStyle.Regular);
            dynamicButton.Click += dynamicButton_Clicked;
            panel_class.Controls.Add(dynamicButton);

            using (MySqlConnection connection = new MySqlConnection(constring))
            {
                connection.Open();
                string query = "SELECT start_time, end_time, day_ FROM linkgenerator_proxy WHERE subj_code = @scode";
                using (MySqlCommand cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@scode", class_name);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string start_time = reader["start_time"].ToString();
                            string end_time = reader["end_time"].ToString();
                            string day = reader["day_"].ToString();

                            CheckButtonStatus(start_time, end_time, day, dynamicButton);
                        }
                    }
                }
            }
        }

        private void CheckButtonStatus(string start_time, string end_time, string day, Button subject)
        {
            try
            {
                // Get values from parameters
                string dayInput = day.Trim();
                string startTimeInput = start_time.Trim();
                string endTimeInput = end_time.Trim();

                // Parse the day
                if (!Enum.TryParse(dayInput, true, out DayOfWeek inputDay))
                {
                    MessageBox.Show("Invalid day input.");
                    return;
                }

                // Parse the start and end times
                if (!TimeSpan.TryParse(startTimeInput, out TimeSpan startTime) ||
                    !TimeSpan.TryParse(endTimeInput, out TimeSpan endTime))
                {
                    MessageBox.Show("Invalid time input.");
                    return;
                }

                // Get the current day and time
                DateTime now = DateTime.Now;
                DayOfWeek currentDay = now.DayOfWeek;
                TimeSpan currentTime = now.TimeOfDay;

                // Check the condition
                if (currentDay == inputDay && currentTime >= startTime && currentTime <= endTime)
                {
                    subject.Enabled = true;
                }
                else
                {
                    subject.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void dynamicButton_Clicked(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender; // Cast sender to Button
            string subjectCode = clickedButton.Text; // Get the subject code from the button text
            int lifePoints = (int)clickedButton.Tag; // Retrieve the life_points from the Tag property
            SubjectClass sc = new SubjectClass(subjectCode, lifePoints);
            parentForm.OpenChildForm(sc);
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel_class_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
