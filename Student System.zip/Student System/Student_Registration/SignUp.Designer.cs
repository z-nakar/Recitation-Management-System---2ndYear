﻿namespace Student_Registration
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            label13 = new Label();
            pic_Logo = new PictureBox();
            label12 = new Label();
            label11 = new Label();
            label8 = new Label();
            label10 = new Label();
            label9 = new Label();
            txt_Pass = new TextBox();
            label5 = new Label();
            txt_LN = new TextBox();
            lbl_StudentApp = new Label();
            panel4 = new Panel();
            label6 = new Label();
            label3 = new Label();
            label4 = new Label();
            btn_SignUp = new Button();
            btnSignIn = new Button();
            panel_Email = new Panel();
            txtContact = new TextBox();
            lbl_StudentID = new Label();
            panel_DOB = new Panel();
            txt_FN = new TextBox();
            lbl_Email = new Label();
            lbl_Cpass = new Label();
            txt_MN = new TextBox();
            panel_StudentID = new Panel();
            chck_ShowPass = new CheckBox();
            panel_Pass = new Panel();
            panel_Cpass = new Panel();
            txt_CPass = new TextBox();
            lbl_Pass = new Label();
            lbl_DOB = new Label();
            lbl_fullName = new Label();
            panel_FullName = new Panel();
            label1 = new Label();
            panel1 = new Panel();
            txtEmail = new TextBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pic_Logo).BeginInit();
            panel4.SuspendLayout();
            panel_Email.SuspendLayout();
            panel_DOB.SuspendLayout();
            panel_StudentID.SuspendLayout();
            panel_Pass.SuspendLayout();
            panel_Cpass.SuspendLayout();
            panel_FullName.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.White;
            label13.Location = new Point(268, 412);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(55, 15);
            label13.TabIndex = 187;
            label13.Text = "U.N.I.T.Y.";
            // 
            // pic_Logo
            // 
            pic_Logo.BackColor = Color.Transparent;
            pic_Logo.Image = (Image)resources.GetObject("pic_Logo.Image");
            pic_Logo.Location = new Point(132, 17);
            pic_Logo.Margin = new Padding(4, 2, 4, 2);
            pic_Logo.Name = "pic_Logo";
            pic_Logo.Size = new Size(105, 90);
            pic_Logo.SizeMode = PictureBoxSizeMode.Zoom;
            pic_Logo.TabIndex = 180;
            pic_Logo.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(257, 392);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(79, 15);
            label12.TabIndex = 182;
            label12.Text = "Developed By";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(14, 215);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(331, 16);
            label11.TabIndex = 186;
            label11.Text = "quality education that develops competent and socially ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(14, 180);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(350, 16);
            label8.TabIndex = 183;
            label8.Text = "The mission of PUP Sta. Maria Bulacan Campus is to offer  ";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(8, 235);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(371, 16);
            label10.TabIndex = 185;
            label10.Text = "responsible professionals. The campus focuses on excellence, ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(35, 198);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(279, 16);
            label9.TabIndex = 184;
            label9.Text = " offer accessible, quality education that shapes";
            // 
            // txt_Pass
            // 
            txt_Pass.BackColor = Color.WhiteSmoke;
            txt_Pass.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_Pass.Location = new Point(10, 6);
            txt_Pass.Margin = new Padding(4, 2, 4, 2);
            txt_Pass.Name = "txt_Pass";
            txt_Pass.PasswordChar = '*';
            txt_Pass.PlaceholderText = "Secure a password";
            txt_Pass.Size = new Size(302, 26);
            txt_Pass.TabIndex = 7;
            txt_Pass.UseSystemPasswordChar = true;
            txt_Pass.TextChanged += txt_Pass_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(40, 120);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(302, 24);
            label5.TabIndex = 181;
            label5.Text = "Recitation Management System";
            // 
            // txt_LN
            // 
            txt_LN.BackColor = Color.WhiteSmoke;
            txt_LN.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_LN.Location = new Point(10, 6);
            txt_LN.Margin = new Padding(4, 2, 4, 2);
            txt_LN.Multiline = true;
            txt_LN.Name = "txt_LN";
            txt_LN.PlaceholderText = "Dela Cruz";
            txt_LN.Size = new Size(302, 24);
            txt_LN.TabIndex = 1;
            // 
            // lbl_StudentApp
            // 
            lbl_StudentApp.AutoSize = true;
            lbl_StudentApp.BackColor = Color.Transparent;
            lbl_StudentApp.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            lbl_StudentApp.ForeColor = Color.Black;
            lbl_StudentApp.Location = new Point(640, 44);
            lbl_StudentApp.Margin = new Padding(4, 0, 4, 0);
            lbl_StudentApp.Name = "lbl_StudentApp";
            lbl_StudentApp.Size = new Size(127, 25);
            lbl_StudentApp.TabIndex = 184;
            lbl_StudentApp.Text = "Registration";
            lbl_StudentApp.Click += lbl_StudentApp_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.BackgroundImage = (Image)resources.GetObject("panel4.BackgroundImage");
            panel4.Controls.Add(label6);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label13);
            panel4.Controls.Add(pic_Logo);
            panel4.Controls.Add(label12);
            panel4.Controls.Add(label5);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(label8);
            panel4.Controls.Add(label10);
            panel4.Controls.Add(label9);
            panel4.ForeColor = Color.Maroon;
            panel4.Location = new Point(-6, -2);
            panel4.Margin = new Padding(4, 2, 4, 2);
            panel4.Name = "panel4";
            panel4.Size = new Size(382, 443);
            panel4.TabIndex = 197;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(45, 274);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(257, 16);
            label6.TabIndex = 189;
            label6.Text = "and nation's socio-economic development.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft Tai Le", 9.75F, FontStyle.Italic, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(14, 255);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(353, 16);
            label3.TabIndex = 188;
            label3.Text = " innovation, and inclusivity, contributing to the community's ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(640, 414);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(122, 13);
            label4.TabIndex = 195;
            label4.Text = "Don't have an account?";
            // 
            // btn_SignUp
            // 
            btn_SignUp.BackColor = Color.Maroon;
            btn_SignUp.FlatAppearance.BorderSize = 0;
            btn_SignUp.FlatStyle = FlatStyle.Flat;
            btn_SignUp.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_SignUp.ForeColor = Color.White;
            btn_SignUp.Location = new Point(556, 376);
            btn_SignUp.Margin = new Padding(4, 2, 4, 2);
            btn_SignUp.Name = "btn_SignUp";
            btn_SignUp.Size = new Size(322, 32);
            btn_SignUp.TabIndex = 0;
            btn_SignUp.Text = "&Sign Up";
            btn_SignUp.UseVisualStyleBackColor = false;
            btn_SignUp.Click += btn_SignUp_Click;
            // 
            // btnSignIn
            // 
            btnSignIn.BackColor = Color.White;
            btnSignIn.FlatAppearance.BorderSize = 0;
            btnSignIn.FlatStyle = FlatStyle.Flat;
            btnSignIn.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnSignIn.ForeColor = Color.Maroon;
            btnSignIn.Location = new Point(758, 409);
            btnSignIn.Margin = new Padding(4, 2, 4, 2);
            btnSignIn.Name = "btnSignIn";
            btnSignIn.Size = new Size(57, 22);
            btnSignIn.TabIndex = 196;
            btnSignIn.Text = "Sign In";
            btnSignIn.TextAlign = ContentAlignment.MiddleLeft;
            btnSignIn.UseVisualStyleBackColor = false;
            btnSignIn.Click += btnSignIn_Click;
            // 
            // panel_Email
            // 
            panel_Email.BackColor = Color.White;
            panel_Email.Controls.Add(txtContact);
            panel_Email.Location = new Point(556, 195);
            panel_Email.Margin = new Padding(4, 2, 4, 2);
            panel_Email.Name = "panel_Email";
            panel_Email.Size = new Size(322, 33);
            panel_Email.TabIndex = 192;
            // 
            // txtContact
            // 
            txtContact.BackColor = Color.WhiteSmoke;
            txtContact.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtContact.Location = new Point(10, 5);
            txtContact.Margin = new Padding(4, 2, 4, 2);
            txtContact.Multiline = true;
            txtContact.Name = "txtContact";
            txtContact.PlaceholderText = "09xxxxxxxx";
            txtContact.Size = new Size(302, 24);
            txtContact.TabIndex = 5;
            // 
            // lbl_StudentID
            // 
            lbl_StudentID.AutoSize = true;
            lbl_StudentID.BackColor = Color.Transparent;
            lbl_StudentID.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_StudentID.ForeColor = Color.Maroon;
            lbl_StudentID.Location = new Point(405, 168);
            lbl_StudentID.Margin = new Padding(4, 0, 4, 0);
            lbl_StudentID.Name = "lbl_StudentID";
            lbl_StudentID.Size = new Size(112, 20);
            lbl_StudentID.TabIndex = 186;
            lbl_StudentID.Text = "Middle Name";
            // 
            // panel_DOB
            // 
            panel_DOB.BackColor = Color.White;
            panel_DOB.Controls.Add(txt_FN);
            panel_DOB.Location = new Point(556, 119);
            panel_DOB.Margin = new Padding(4, 2, 4, 2);
            panel_DOB.Name = "panel_DOB";
            panel_DOB.Size = new Size(322, 33);
            panel_DOB.TabIndex = 182;
            // 
            // txt_FN
            // 
            txt_FN.BackColor = Color.WhiteSmoke;
            txt_FN.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_FN.Location = new Point(10, 5);
            txt_FN.Margin = new Padding(4, 2, 4, 2);
            txt_FN.Multiline = true;
            txt_FN.Name = "txt_FN";
            txt_FN.PlaceholderText = "Juan";
            txt_FN.Size = new Size(302, 24);
            txt_FN.TabIndex = 2;
            // 
            // lbl_Email
            // 
            lbl_Email.AutoSize = true;
            lbl_Email.BackColor = Color.Transparent;
            lbl_Email.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_Email.ForeColor = Color.Maroon;
            lbl_Email.Location = new Point(406, 207);
            lbl_Email.Margin = new Padding(4, 0, 4, 0);
            lbl_Email.Name = "lbl_Email";
            lbl_Email.Size = new Size(139, 20);
            lbl_Email.TabIndex = 193;
            lbl_Email.Text = "Contact Number";
            // 
            // lbl_Cpass
            // 
            lbl_Cpass.AutoSize = true;
            lbl_Cpass.BackColor = Color.Transparent;
            lbl_Cpass.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_Cpass.ForeColor = Color.Maroon;
            lbl_Cpass.Location = new Point(405, 321);
            lbl_Cpass.Margin = new Padding(4, 0, 4, 0);
            lbl_Cpass.Name = "lbl_Cpass";
            lbl_Cpass.Size = new Size(153, 20);
            lbl_Cpass.TabIndex = 191;
            lbl_Cpass.Text = "Confirm Password";
            // 
            // txt_MN
            // 
            txt_MN.BackColor = Color.WhiteSmoke;
            txt_MN.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_MN.Location = new Point(10, 6);
            txt_MN.Margin = new Padding(4, 2, 4, 2);
            txt_MN.Multiline = true;
            txt_MN.Name = "txt_MN";
            txt_MN.PlaceholderText = "Gonzales";
            txt_MN.Size = new Size(302, 24);
            txt_MN.TabIndex = 3;
            // 
            // panel_StudentID
            // 
            panel_StudentID.BackColor = Color.White;
            panel_StudentID.Controls.Add(txt_MN);
            panel_StudentID.Location = new Point(556, 157);
            panel_StudentID.Margin = new Padding(4, 2, 4, 2);
            panel_StudentID.Name = "panel_StudentID";
            panel_StudentID.Size = new Size(322, 33);
            panel_StudentID.TabIndex = 185;
            // 
            // chck_ShowPass
            // 
            chck_ShowPass.AutoSize = true;
            chck_ShowPass.BackColor = Color.Transparent;
            chck_ShowPass.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            chck_ShowPass.ForeColor = Color.DimGray;
            chck_ShowPass.Location = new Point(761, 350);
            chck_ShowPass.Margin = new Padding(4, 2, 4, 2);
            chck_ShowPass.Name = "chck_ShowPass";
            chck_ShowPass.Size = new Size(102, 17);
            chck_ShowPass.TabIndex = 187;
            chck_ShowPass.Text = "Show Password";
            chck_ShowPass.UseVisualStyleBackColor = false;
            chck_ShowPass.CheckedChanged += chck_ShowPass_CheckedChanged;
            // 
            // panel_Pass
            // 
            panel_Pass.BackColor = Color.White;
            panel_Pass.Controls.Add(txt_Pass);
            panel_Pass.Location = new Point(556, 271);
            panel_Pass.Margin = new Padding(4, 2, 4, 2);
            panel_Pass.Name = "panel_Pass";
            panel_Pass.Size = new Size(322, 42);
            panel_Pass.TabIndex = 188;
            // 
            // panel_Cpass
            // 
            panel_Cpass.BackColor = Color.White;
            panel_Cpass.Controls.Add(txt_CPass);
            panel_Cpass.Location = new Point(556, 309);
            panel_Cpass.Margin = new Padding(4, 2, 4, 2);
            panel_Cpass.Name = "panel_Cpass";
            panel_Cpass.Size = new Size(322, 45);
            panel_Cpass.TabIndex = 189;
            // 
            // txt_CPass
            // 
            txt_CPass.BackColor = Color.WhiteSmoke;
            txt_CPass.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_CPass.Location = new Point(10, 7);
            txt_CPass.Margin = new Padding(4, 2, 4, 2);
            txt_CPass.Name = "txt_CPass";
            txt_CPass.PasswordChar = '*';
            txt_CPass.PlaceholderText = "Confirm your password";
            txt_CPass.Size = new Size(302, 26);
            txt_CPass.TabIndex = 8;
            txt_CPass.UseSystemPasswordChar = true;
            // 
            // lbl_Pass
            // 
            lbl_Pass.AutoSize = true;
            lbl_Pass.BackColor = Color.Transparent;
            lbl_Pass.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_Pass.ForeColor = Color.Maroon;
            lbl_Pass.Location = new Point(405, 283);
            lbl_Pass.Margin = new Padding(4, 0, 4, 0);
            lbl_Pass.Name = "lbl_Pass";
            lbl_Pass.Size = new Size(86, 20);
            lbl_Pass.TabIndex = 190;
            lbl_Pass.Text = "Password";
            // 
            // lbl_DOB
            // 
            lbl_DOB.AutoSize = true;
            lbl_DOB.BackColor = Color.Transparent;
            lbl_DOB.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_DOB.ForeColor = Color.Maroon;
            lbl_DOB.Location = new Point(405, 132);
            lbl_DOB.Margin = new Padding(4, 0, 4, 0);
            lbl_DOB.Name = "lbl_DOB";
            lbl_DOB.Size = new Size(96, 20);
            lbl_DOB.TabIndex = 183;
            lbl_DOB.Text = "First Name";
            // 
            // lbl_fullName
            // 
            lbl_fullName.AutoSize = true;
            lbl_fullName.BackColor = Color.Transparent;
            lbl_fullName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_fullName.ForeColor = Color.Maroon;
            lbl_fullName.Location = new Point(406, 93);
            lbl_fullName.Margin = new Padding(4, 0, 4, 0);
            lbl_fullName.Name = "lbl_fullName";
            lbl_fullName.Size = new Size(95, 20);
            lbl_fullName.TabIndex = 181;
            lbl_fullName.Text = "Last Name";
            // 
            // panel_FullName
            // 
            panel_FullName.BackColor = Color.White;
            panel_FullName.Controls.Add(txt_LN);
            panel_FullName.Location = new Point(556, 81);
            panel_FullName.Margin = new Padding(4, 2, 4, 2);
            panel_FullName.Name = "panel_FullName";
            panel_FullName.Size = new Size(322, 33);
            panel_FullName.TabIndex = 180;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Maroon;
            label1.Location = new Point(601, 15);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(217, 25);
            label1.TabIndex = 184;
            label1.Text = "Student Application";
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(txtEmail);
            panel1.Location = new Point(556, 233);
            panel1.Margin = new Padding(4, 2, 4, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(322, 33);
            panel1.TabIndex = 198;
            // 
            // txtEmail
            // 
            txtEmail.BackColor = Color.WhiteSmoke;
            txtEmail.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.Location = new Point(10, 3);
            txtEmail.Margin = new Padding(4, 2, 4, 2);
            txtEmail.Multiline = true;
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "example@domain.com";
            txtEmail.Size = new Size(302, 24);
            txtEmail.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Maroon;
            label2.Location = new Point(406, 245);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(124, 20);
            label2.TabIndex = 199;
            label2.Text = "Email Address";
            // 
            // SignUp
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(899, 434);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lbl_StudentApp);
            Controls.Add(panel4);
            Controls.Add(label4);
            Controls.Add(btn_SignUp);
            Controls.Add(btnSignIn);
            Controls.Add(panel_Email);
            Controls.Add(lbl_StudentID);
            Controls.Add(panel_DOB);
            Controls.Add(lbl_Email);
            Controls.Add(lbl_Cpass);
            Controls.Add(panel_StudentID);
            Controls.Add(chck_ShowPass);
            Controls.Add(panel_Pass);
            Controls.Add(panel_Cpass);
            Controls.Add(lbl_Pass);
            Controls.Add(lbl_DOB);
            Controls.Add(lbl_fullName);
            Controls.Add(panel_FullName);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.Fixed3D;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 2, 4, 2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "SignUp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SignUp";
            Load += SignUp_Load;
            ((System.ComponentModel.ISupportInitialize)pic_Logo).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel_Email.ResumeLayout(false);
            panel_Email.PerformLayout();
            panel_DOB.ResumeLayout(false);
            panel_DOB.PerformLayout();
            panel_StudentID.ResumeLayout(false);
            panel_StudentID.PerformLayout();
            panel_Pass.ResumeLayout(false);
            panel_Pass.PerformLayout();
            panel_Cpass.ResumeLayout(false);
            panel_Cpass.PerformLayout();
            panel_FullName.ResumeLayout(false);
            panel_FullName.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label13;
        private PictureBox pic_Logo;
        private Label label12;
        private Label label11;
        private Label label8;
        private Label label10;
        private Label label9;
        private TextBox txt_Pass;
        private Label label5;
        private TextBox txt_LN;
        private Label lbl_StudentApp;
        private Panel panel4;
        private Label label4;
        private Button btn_SignUp;
        private Button btnSignIn;
        private Panel panel_Email;
        private Label lbl_StudentID;
        private Panel panel_DOB;
        private Label lbl_Email;
        private Label lbl_Cpass;
        private TextBox txt_MN;
        private Panel panel_StudentID;
        private CheckBox chck_ShowPass;
        private Panel panel_Pass;
        private Panel panel_Cpass;
        private TextBox txt_CPass;
        private Label lbl_Pass;
        private Label lbl_DOB;
        private Label lbl_fullName;
        private Panel panel_FullName;
        private Label label1;
        private TextBox txt_FN;
        private Panel panel1;
        private TextBox txtEmail;
        private Label label2;
        private TextBox txtContact;
        private Label label6;
        private Label label3;
    }
}