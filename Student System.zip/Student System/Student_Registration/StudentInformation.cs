﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Student_Registration
{
    public partial class StudentInformation : Form
    {

        //for raduis button

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
       int nLeftRect, // x-coordinate of upper-left corner
       int nTopRect, // y-coordinate of upper-left corner
       int nRightRect, // x-coordinate of lower-right corner
       int nBottomRect, // y-coordinate of lower-right corner
       int nWidthEllipse, // height of ellipse
       int nHeightEllipse // width of ellipse
    );






        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        public StudentInformation(StudentSystem parentForm)
        {

            InitializeComponent();
            LoadStudentInformation();

            //for raduis button
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            txtFirstName.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtFirstName.Width, txtFirstName.Height, 10, 10));
            txtMiddleName.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtMiddleName.Width, txtMiddleName.Height, 10, 10));
            txtLastName.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtLastName.Width, txtLastName.Height, 10, 10));
            maskedTextBox_contact.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, maskedTextBox_contact.Width, maskedTextBox_contact.Height, 10, 10));
            txtEmail.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtEmail.Width, txtEmail.Height, 10, 10));
            txtPassword.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, txtPassword.Width, txtPassword.Height, 10, 10));
         
        }

        private void LoadStudentInformation()
        {
            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT first_name, last_name, email_, password_, contact, middle_name FROM signup_tb WHERE std_ID = @std_ID";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);

                        MySqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            txtFirstName.Text = reader.GetString(0);
                            txtLastName.Text = reader.GetString(1);
                            txtEmail.Text = reader.GetString(2);
                            txtPassword.Text = reader.GetString(3);
                            string contact = reader.GetString(4);
                            if (!string.IsNullOrEmpty(contact) && contact.Length > 1)
                            {
                                contact = contact.Substring(1);
                            }
                            maskedTextBox_contact.Text = contact;
                            txtMiddleName.Text = reader.GetString(5);
                        }

                        reader.Close();
                    }
                    CalculateAndDisplayTotalReceivePoints();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void CalculateAndDisplayTotalReceivePoints()
        {
            int totalReceivePoints = 0;

            using (MySqlConnection conn = new MySqlConnection(constring))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT recieve_points FROM signup_tb WHERE std_ID = @std_ID";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);

                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            totalReceivePoints = Convert.ToInt32(result);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while calculating total receive points: " + ex.Message);
                }
            }

            txtbx_totalRecievePoints.Text = totalReceivePoints.ToString();
        }



        private void StudentInformation_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBox_contact_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
