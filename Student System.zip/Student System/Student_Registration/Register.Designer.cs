﻿namespace Student_Registration
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pictureBox4 = new PictureBox();
            txtFirstName = new TextBox();
            txt_classPass = new TextBox();
            cbSection = new ComboBox();
            txtLastName = new TextBox();
            cbCourse = new ComboBox();
            lbl_CodeSub = new Label();
            label10 = new Label();
            label1 = new Label();
            btn_ClassRegister = new Button();
            pictureBox1 = new PictureBox();
            btn_uploadPhoto = new Button();
            pic_uploadPhoto = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pic_uploadPhoto).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.White;
            label6.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(68, 388);
            label6.Name = "label6";
            label6.Size = new Size(135, 20);
            label6.TabIndex = 165;
            label6.Text = "Class Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.White;
            label5.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(348, 345);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 164;
            label5.Text = "Section";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(68, 343);
            label4.Name = "label4";
            label4.Size = new Size(66, 20);
            label4.TabIndex = 163;
            label4.Text = "Course";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(68, 294);
            label3.Name = "label3";
            label3.Size = new Size(95, 20);
            label3.TabIndex = 162;
            label3.Text = "Last Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(68, 247);
            label2.Name = "label2";
            label2.Size = new Size(96, 20);
            label2.TabIndex = 161;
            label2.Text = "First Name";
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Transparent;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(490, 390);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(15, 15);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 160;
            pictureBox4.TabStop = false;
            // 
            // txtFirstName
            // 
            txtFirstName.BackColor = Color.WhiteSmoke;
            txtFirstName.BorderStyle = BorderStyle.None;
            txtFirstName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtFirstName.Location = new Point(209, 247);
            txtFirstName.Margin = new Padding(3, 2, 3, 2);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.PlaceholderText = "First Name";
            txtFirstName.ReadOnly = true;
            txtFirstName.Size = new Size(304, 19);
            txtFirstName.TabIndex = 150;
            // 
            // txt_classPass
            // 
            txt_classPass.BackColor = Color.WhiteSmoke;
            txt_classPass.BorderStyle = BorderStyle.None;
            txt_classPass.Font = new Font("Consolas", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_classPass.Location = new Point(209, 388);
            txt_classPass.Margin = new Padding(3, 2, 3, 2);
            txt_classPass.Name = "txt_classPass";
            txt_classPass.PlaceholderText = "***************";
            txt_classPass.Size = new Size(304, 19);
            txt_classPass.TabIndex = 151;
            txt_classPass.UseSystemPasswordChar = true;
            // 
            // cbSection
            // 
            cbSection.BackColor = Color.WhiteSmoke;
            cbSection.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            cbSection.FormattingEnabled = true;
            cbSection.Items.AddRange(new object[] { "1-1", "1-2", "2-1", "2-2", "3-1", "3-2", "4-1", "4-2" });
            cbSection.Location = new Point(425, 342);
            cbSection.Margin = new Padding(3, 2, 3, 2);
            cbSection.Name = "cbSection";
            cbSection.Size = new Size(88, 28);
            cbSection.TabIndex = 157;
            // 
            // txtLastName
            // 
            txtLastName.BackColor = Color.WhiteSmoke;
            txtLastName.BorderStyle = BorderStyle.None;
            txtLastName.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtLastName.Location = new Point(209, 294);
            txtLastName.Margin = new Padding(3, 2, 3, 2);
            txtLastName.Name = "txtLastName";
            txtLastName.PlaceholderText = "Last Name";
            txtLastName.ReadOnly = true;
            txtLastName.Size = new Size(304, 19);
            txtLastName.TabIndex = 149;
            // 
            // cbCourse
            // 
            cbCourse.BackColor = Color.WhiteSmoke;
            cbCourse.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular, GraphicsUnit.Point);
            cbCourse.FormattingEnabled = true;
            cbCourse.Location = new Point(209, 342);
            cbCourse.Margin = new Padding(3, 2, 3, 2);
            cbCourse.Name = "cbCourse";
            cbCourse.Size = new Size(133, 28);
            cbCourse.TabIndex = 156;
            // 
            // lbl_CodeSub
            // 
            lbl_CodeSub.AutoSize = true;
            lbl_CodeSub.BackColor = Color.White;
            lbl_CodeSub.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_CodeSub.ForeColor = Color.Maroon;
            lbl_CodeSub.Location = new Point(272, 99);
            lbl_CodeSub.Name = "lbl_CodeSub";
            lbl_CodeSub.Size = new Size(125, 25);
            lbl_CodeSub.TabIndex = 159;
            lbl_CodeSub.Text = "COMP 001";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(297, 144);
            label10.Name = "label10";
            label10.Size = new Size(168, 25);
            label10.TabIndex = 158;
            label10.Text = "INFORMATION";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(209, 144);
            label1.Name = "label1";
            label1.Size = new Size(93, 25);
            label1.TabIndex = 155;
            label1.Text = "CLASS ";
            // 
            // btn_ClassRegister
            // 
            btn_ClassRegister.BackColor = Color.Maroon;
            btn_ClassRegister.FlatAppearance.BorderSize = 0;
            btn_ClassRegister.FlatStyle = FlatStyle.Flat;
            btn_ClassRegister.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btn_ClassRegister.ForeColor = SystemColors.Control;
            btn_ClassRegister.Location = new Point(209, 441);
            btn_ClassRegister.Margin = new Padding(3, 2, 3, 2);
            btn_ClassRegister.Name = "btn_ClassRegister";
            btn_ClassRegister.Size = new Size(304, 29);
            btn_ClassRegister.TabIndex = 154;
            btn_ClassRegister.Text = "Register";
            btn_ClassRegister.UseVisualStyleBackColor = false;
            btn_ClassRegister.Click += btn_ClassRegister_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(515, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(21, 18);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 166;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_1;
            // 
            // btn_uploadPhoto
            // 
            btn_uploadPhoto.BackColor = Color.Maroon;
            btn_uploadPhoto.FlatAppearance.BorderSize = 0;
            btn_uploadPhoto.FlatStyle = FlatStyle.Flat;
            btn_uploadPhoto.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btn_uploadPhoto.ForeColor = SystemColors.Control;
            btn_uploadPhoto.Location = new Point(63, 182);
            btn_uploadPhoto.Margin = new Padding(3, 2, 3, 2);
            btn_uploadPhoto.Name = "btn_uploadPhoto";
            btn_uploadPhoto.Size = new Size(99, 32);
            btn_uploadPhoto.TabIndex = 168;
            btn_uploadPhoto.Text = "Browse Photo ";
            btn_uploadPhoto.UseVisualStyleBackColor = false;
            btn_uploadPhoto.Click += btn_uploadPhoto_Click;
            // 
            // pic_uploadPhoto
            // 
            pic_uploadPhoto.Image = Properties.Resources.unnamed__2_;
            pic_uploadPhoto.Location = new Point(59, 88);
            pic_uploadPhoto.Margin = new Padding(3, 2, 3, 2);
            pic_uploadPhoto.Name = "pic_uploadPhoto";
            pic_uploadPhoto.Size = new Size(105, 90);
            pic_uploadPhoto.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_uploadPhoto.TabIndex = 169;
            pic_uploadPhoto.TabStop = false;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(553, 498);
            Controls.Add(btn_uploadPhoto);
            Controls.Add(pic_uploadPhoto);
            Controls.Add(pictureBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox4);
            Controls.Add(txtFirstName);
            Controls.Add(txt_classPass);
            Controls.Add(cbSection);
            Controls.Add(txtLastName);
            Controls.Add(cbCourse);
            Controls.Add(lbl_CodeSub);
            Controls.Add(label10);
            Controls.Add(label1);
            Controls.Add(btn_ClassRegister);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Register";
            Text = "Register";
            Load += Register_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pic_uploadPhoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox4;
        private TextBox txtFirstName;
        private TextBox txt_classPass;
        private ComboBox cbSection;
        private TextBox txtLastName;
        private ComboBox cbCourse;
        private Label lbl_CodeSub;
        private Label label10;
        private Label label1;
        private Button btn_ClassRegister;
        private PictureBox pictureBox1;
        private Button btn_uploadPhoto;
        private PictureBox pic_uploadPhoto;
    }
}