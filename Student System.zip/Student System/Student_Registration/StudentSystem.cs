﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Student_Registration
{
    public partial class StudentSystem : Form
    {

        //for raduis button

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
    (
       int nLeftRect, // x-coordinate of upper-left corner
       int nTopRect, // y-coordinate of upper-left corner
       int nRightRect, // x-coordinate of lower-right corner
       int nBottomRect, // y-coordinate of lower-right corner
       int nWidthEllipse, // height of ellipse
       int nHeightEllipse // width of ellipse
    );


        // Active form to keep track of the current child form
        private Form activeForm = null;

        string constring = "server=localhost;database=student_application;uid=root;password=admin2004-01-15";
        public static double points;
        private System.Timers.Timer timer;

        public StudentSystem()
        {
            InitializeComponent();
            StartTimer();
            lbl_pts.Text += SignIn.pts;

            //for raduis button
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 10, 10));
            btn_SCL.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_SCL.Width, btn_SCL.Height, 5, 5));
            btn_ES.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_ES.Width, btn_ES.Height, 5, 5));
            btn_SI.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btn_SI.Width, btn_SI.Height, 5, 5));
            btnGiftPoints.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btnGiftPoints.Width, btnGiftPoints.Height, 5, 5));
            btnLogOut.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, btnLogOut.Width, btnLogOut.Height, 5, 5));
        }

        private void StartTimer()
        {
            timer = new System.Timers.Timer();
            timer.Interval = 100;
            timer.Elapsed += OnTimedEvent;
            timer.AutoReset = true;
            timer.Enabled = true;
        }

        private void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            using (MySqlConnection con = new MySqlConnection(constring))
            {
                con.Open();
                string query = "SELECT recitation_pts FROM signup_tb WHERE std_ID = @std_ID";
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@std_ID", SignIn.student_ID);
                    object recitation_pts = cmd.ExecuteScalar();
                    if (recitation_pts != null)
                    {
                        double newPoints = Convert.ToDouble(recitation_pts);
                        if (newPoints != points)
                        {
                            points = newPoints;
                            UpdatePointsLabel(points); // Update label with new points
                        }
                    }
                }
            }
        }

        private void UpdatePointsLabel(double newPoints)
        {
            // Ensure that the label is updated on the UI thread
            if (lbl_pts.InvokeRequired)
            {
                lbl_pts.Invoke(new Action(() => lbl_pts.Text = $"Points: {newPoints}"));
            }
            else
            {
                lbl_pts.Text = $"Points: {newPoints}";
            }
        }

        // Method to open a child form within the panel_main
        public void OpenChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;

            panel_main2.Controls.Add(childForm);
            panel_main2.Tag = childForm;

            childForm.BringToFront();
            childForm.Show();
        }


        private void btn_SCL_Click_1(object sender, EventArgs e)
        {
            OpenChildForm(new ClassList(this));
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_ES_Click(object sender, EventArgs e)
        {
            OpenChildForm(new EnrolledSubject(this));
        }

        private void btnGiftPoints_Click(object sender, EventArgs e)
        {
            OpenChildForm(new SharePoints(this));
        }

        private void btn_SI_Click(object sender, EventArgs e)
        {
            OpenChildForm(new StudentInformation(this));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lbl_pts_Click(object sender, EventArgs e)
        {

        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            SignIn si = new SignIn();
            si.Show();
            this.Hide();
        }

        private void StudentSystem_Load(object sender, EventArgs e)
        {

        }
    }
}
